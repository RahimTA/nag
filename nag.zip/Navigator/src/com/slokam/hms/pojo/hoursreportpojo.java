package com.slokam.hms.pojo;

import java.util.List;

public class hoursreportpojo {
	
	private String vehicleno;
	private String type;
	private String startlocation;
	private String endlocation;
	private String fromtime;
	private String totime;
	private String distance;
	private String date;
	private List<String> branches;
	private boolean  firststnumber;
	private boolean secondnumber;
	private boolean thirdnumber;
	private boolean fourthnumber;
	private boolean fivthnumber;
	private boolean sixsthnumber;
	
	public boolean isFirststnumber() {
		return firststnumber;
	}
	public void setFirststnumber(boolean firststnumber) {
		this.firststnumber = firststnumber;
	}
	public boolean isSecondnumber() {
		return secondnumber;
	}
	public void setSecondnumber(boolean secondnumber) {
		this.secondnumber = secondnumber;
	}
	public boolean isThirdnumber() {
		return thirdnumber;
	}
	public void setThirdnumber(boolean thirdnumber) {
		this.thirdnumber = thirdnumber;
	}
	public boolean isFourthnumber() {
		return fourthnumber;
	}
	public void setFourthnumber(boolean fourthnumber) {
		this.fourthnumber = fourthnumber;
	}
	public boolean isFivthnumber() {
		return fivthnumber;
	}
	public void setFivthnumber(boolean fivthnumber) {
		this.fivthnumber = fivthnumber;
	}
	public boolean isSixsthnumber() {
		return sixsthnumber;
	}
	public void setSixsthnumber(boolean sixsthnumber) {
		this.sixsthnumber = sixsthnumber;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<String> getBranches() {
		return branches;
	}
	public void setBranches(List<String> branches) {
		this.branches = branches;
	}
 
	public String getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(String vehicleno) {
		this.vehicleno = vehicleno;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStartlocation() {
		return startlocation;
	}
	public void setStartlocation(String startlocation) {
		this.startlocation = startlocation;
	}
	public String getEndlocation() {
		return endlocation;
	}
	public void setEndlocation(String endlocation) {
		this.endlocation = endlocation;
	}
	public String getFromtime() {
		return fromtime;
	}
	public void setFromtime(String fromtime) {
		this.fromtime = fromtime;
	}
	public String getTotime() {
		return totime;
	}
	public void setTotime(String totime) {
		this.totime = totime;
	}
	public String getDistance() {
		return distance;
	}
	public void setDistance(String distance) {
		this.distance = distance;
	}
	private searchpojo serch;
	public searchpojo getSerch() {
		return serch;
	}
	public void setSerch(searchpojo serch) {
		this.serch = serch;
	}
	

}
