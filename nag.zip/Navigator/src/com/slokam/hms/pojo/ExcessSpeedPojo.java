package com.slokam.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name="excess_speed")
public class ExcessSpeedPojo 
{
 
	@Override
	public String toString() {
		return "ExcessSpeedPojo [fromDate=" + fromDate + ", toDate=" + toDate
				+ ", speedLimit=" + speedLimit + ", branch=" + branch
				+ ", vehicles=" + vehicles + "]";
	}
	private String fromDate;
	private String toDate;
	
	@Column
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	@Column
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Column
	public String getSpeedLimit() {
		return speedLimit;
	}
	public void setSpeedLimit(String speedLimit) {
		this.speedLimit = speedLimit;
	}
	@Column
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Column
	public String getVehicles() {
		return vehicles;
	}
	public void setVehicles(String vehicles) {
		this.vehicles = vehicles;
	}
	private String speedLimit;
	private String branch;
	private String vehicles;
}
