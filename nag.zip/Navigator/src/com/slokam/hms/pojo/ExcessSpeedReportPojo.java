package com.slokam.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;


public class ExcessSpeedReportPojo 
{

	@Override
	public String toString() {
		return "ExcessSpeedReportPojo [vehicleNO=" + vehicleNO
				+ ", vehicleType=" + vehicleType + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", speed=" + speed + ", date="
				+ date + ", month=" + month + ", year=" + year + ", hour="
				+ hour + ", minit=" + minit + ", second=" + second
				+ ", newDate=" + newDate + ", newTime=" + newTime + ", newLoc="
				+ newLoc + "]";
	}
	private String vehicleNO;
	private String vehicleType;
	private String latitude;
	private String longitude;
	private String speed;
	private String date;
	private String month;
	private String year;
	private String hour;
	private String minit;
	private String second;
	private String newDate;
	private String newTime;
	private String newLoc;
	public String getNewDate() {
		return newDate;
	}
	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}
	public String getNewTime() {
		return newTime;
	}
	public void setNewTime(String newTime) {
		this.newTime = newTime;
	}
	public String getNewLoc() {
		return newLoc;
	}
	public void setNewLoc(String newLoc) {
		this.newLoc = newLoc;
	}
	public String getVehicleNO() {
		return vehicleNO;
	}
	public void setVehicleNO(String vehicleNO) {
		this.vehicleNO = vehicleNO;
	}
	
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	
	public String getMinit() {
		return minit;
	}
	public void setMinit(String minit) {
		this.minit = minit;
	}
	
	public String getSecond() {
		return second;
	}
	public void setSecond(String second) {
		this.second = second;
	}
	
	
	
}
