package com.slokam.hms.pojo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="branch")
public class BranchEntity {
	private int id;
	private String name;
	private String phone;
	private Set<VehiclesEntity> vehical;
	
	@OneToMany(mappedBy="branchref")
	public Set<VehiclesEntity> getVehical() {
		return vehical;
	}
	public void setVehical(Set<VehiclesEntity> vehical) {
		this.vehical = vehical;
	}
	
	@Id
	@GeneratedValue
	@Column(name="id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	@Column(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name="phone")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

}
