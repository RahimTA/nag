package com.slokam.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="vehical")
public class VehiclesEntity {
	
	private int id;
	private String number;
	private int type;
	private String description;
	private BranchEntity branchref;
	
	

	@ManyToOne
	@JoinColumn(name="branch")
	public BranchEntity getBranchref() {
		return branchref;
	}

	public void setBranchref(BranchEntity branchref) {
		this.branchref = branchref;
	}
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="number")
	public String getNumber() {
		return number;
	}
	

	
	public void setNumber(String number) {
		this.number = number;
	}
	@Column(name="type")
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	@Column(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
