package com.slokam.hms.pojo;

public class HourlySearchpojo {
	
	private int id;
	private String normaldataindication;
	private String vehicalid;
	private String vehicalname;
	
	private String date;
	private String month;
	private String year;
	private String dmy;
	private String hour;
	private String minit;
	private String second;
	private String time;
	private String Latitude;
	private String Longitude;
	private String speed;
	private int distance;
	private String endlocation;
	private String time2;
	private String startlocation;
	public String getTime2() {
		return time2;
	}
	public void setTime2(String time2) {
		this.time2 = time2;
	}
	public String getEndlocation() {
		return endlocation;
	}
	public void setEndlocation(String endlocation) {
		this.endlocation = endlocation;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	
	public String getStartlocation() {
		return startlocation;
	}
	public void setStartlocation(String startlocation) {
		this.startlocation = startlocation;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNormaldataindication() {
		return normaldataindication;
	}
	public void setNormaldataindication(String normaldataindication) {
		this.normaldataindication = normaldataindication;
	}
	public String getVehicalid() {
		return vehicalid;
	}
	public void setVehicalid(String vehicalid) {
		this.vehicalid = vehicalid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getDmy() {
		return dmy;
	}
	public void setDmy(String dmy) {
		this.dmy = dmy;
	}
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	public String getMinit() {
		return minit;
	}
	public void setMinit(String minit) {
		this.minit = minit;
	}
	public String getSecond() {
		return second;
	}
	public void setSecond(String second) {
		this.second = second;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getLatitude() {
		return Latitude;
	}
	public void setLatitude(String latitude) {
		Latitude = latitude;
	}
	public String getLongitude() {
		return Longitude;
	}
	public void setLongitude(String longitude) {
		Longitude = longitude;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	public String getVehicalname() {
		return vehicalname;
	}
	public void setVehicalname(String vehicalname) {
		this.vehicalname = vehicalname;
	}
	
	

}
