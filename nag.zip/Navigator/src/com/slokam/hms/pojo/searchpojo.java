package com.slokam.hms.pojo;

import java.util.List;



public class searchpojo {
	
	private String date;
	private List<String> branches;
	private boolean  firststnumber;
	private boolean secondnumber;
	private boolean thirdnumber;
	private boolean fourthnumber;
	private boolean fivthnumber;
	private boolean sixsthnumber;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<String> getBranches() {
		return branches;
	}
	public void setBranches(List<String> branches) {
		this.branches = branches;
	}
	public boolean isFirststnumber() {
		return firststnumber;
	}
	public void setFirststnumber(boolean firststnumber) {
		this.firststnumber = firststnumber;
	}
	public boolean isSecondnumber() {
		return secondnumber;
	}
	public void setSecondnumber(boolean secondnumber) {
		this.secondnumber = secondnumber;
	}
	public boolean isThirdnumber() {
		return thirdnumber;
	}
	public void setThirdnumber(boolean thirdnumber) {
		this.thirdnumber = thirdnumber;
	}
	public boolean isFourthnumber() {
		return fourthnumber;
	}
	public void setFourthnumber(boolean fourthnumber) {
		this.fourthnumber = fourthnumber;
	}
	public boolean isFivthnumber() {
		return fivthnumber;
	}
	public void setFivthnumber(boolean fivthnumber) {
		this.fivthnumber = fivthnumber;
	}
	public boolean isSixsthnumber() {
		return sixsthnumber;
	}
	public void setSixsthnumber(boolean sixsthnumber) {
		this.sixsthnumber = sixsthnumber;
	}
	

}
