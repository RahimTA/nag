package com.slokam.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="insert")
public class InsertPojo {
	
    private Integer id;
	private Integer productId;
	private String manufacturedBy;
	private String sim;
	private String firmVersion;
	private Integer phoneNumber;
	private String imei;
	private String productModel;
	private String firmName;
	private String firmDescription;
	private String vehicalNumber;
	

	@Column(name="id")
	@GeneratedValue
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name="productId")
		public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	@Column(name="manufacturedBy")
	public String getManufacturedBy() {
		return manufacturedBy;
	}
	public void setManufacturedBy(String manufacturedBy) {
		this.manufacturedBy = manufacturedBy;
	}
	
	@Column(name="sim")
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	
	@Column(name="firmVersion")
	public String getFirmVersion() {
		return firmVersion;
	}
	public void setFirmVersion(String firmVersion) {
		this.firmVersion = firmVersion;
	}
	
	@Column(name="phoneNumber")
	public Integer getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	@Column(name="imei")
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	
  @Column(name="productModel")
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	@Column(name="firmName")
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	

	@Column(name="firmDescription")
	public String getFirmDescription() {
		return firmDescription;
	}
	public void setFirmDescription(String firmDescription) {
		this.firmDescription = firmDescription;
	}
	@Column(name="vehicalNumber")
	public String getVehicalNumber() {
		return vehicalNumber;
	}
	public void setVehicalNumber(String vehicalNumber) {
		this.vehicalNumber = vehicalNumber;
	}

}
