package com.slokam.hms.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehical")
public class VehiclePojo 
{
private Integer id;
private String number;
private String  type;
private String description;
private Integer branch;
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Column(name="number")
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
@Column(name="type")
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
@Column(name="description")
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
@Column(name="branch")
public Integer getBranch() {
	return branch;
}
public void setBranch(Integer branch) {
	this.branch = branch;
}



}
