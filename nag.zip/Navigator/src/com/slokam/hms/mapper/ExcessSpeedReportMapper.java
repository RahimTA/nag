package com.slokam.hms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.slokam.hms.pojo.ExcessSpeedReportPojo;

public class ExcessSpeedReportMapper implements RowMapper<ExcessSpeedReportPojo>
{

	public ExcessSpeedReportPojo mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		ExcessSpeedReportPojo exrpojo = new ExcessSpeedReportPojo();
		
		exrpojo.setVehicleNO(rs.getString(1));
		exrpojo.setVehicleType(rs.getString(2));
		exrpojo.setLatitude(rs.getString(3));
		exrpojo.setLongitude(rs.getString(4));
		exrpojo.setSpeed(rs.getString(5));
		exrpojo.setDate(rs.getString(6));
		exrpojo.setMonth(rs.getString(7));
		exrpojo.setYear(rs.getString(8));
		exrpojo.setHour(rs.getString(9));
		exrpojo.setMinit(rs.getString(10));
		exrpojo.setSecond(rs.getString(11));
		
		
		return exrpojo;
	}

}
