package com.slokam.hms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.slokam.hms.screenpojo.ContactPojo;

public class ContactDetailsMapper implements RowMapper<ContactPojo>{

	public ContactPojo mapRow(ResultSet rs, int arg1) throws SQLException {
		
		ContactPojo pojo = new ContactPojo();
    	pojo.setId(rs.getString("id"));
    	pojo.setCity(rs.getString("city"));
    	pojo.setEmail(rs.getString("email"));
    	pojo.setFirstName(rs.getString("firstname"));
    	pojo.setLandlineNumber(rs.getString("landline"));
    	pojo.setLastName(rs.getString("lastname"));
    	pojo.setMiddleName(rs.getString("middlename"));
    	pojo.setMobileNumber(rs.getString("mobile"));
    	pojo.setStartupComp(rs.getString("startupcomp"));
		return pojo;
	}

	
}
