package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.screenpojo.LoginPojo;

public class LoginDAO extends HibernateDaoSupport{

	
	public LoginPojo  login(LoginPojo pojo){
		 List<LoginPojo> list = (List<LoginPojo>)getHibernateTemplate().find("from LoginPojo where userName=? and password=?",pojo.getUserName(),pojo.getPassword());
		if(list!=null && list.size()>0)
			return list.get(0);
		else
			return null;
	}
}
