package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.screenpojo.AreaPojo;
import com.slokam.hms.screenpojo.CityPojo;

public class CityDAO extends HibernateDaoSupport{

	public List<CityPojo> getCities()
	{
		List<CityPojo> cities = (List<CityPojo>)getHibernateTemplate().find("from CityPojo");
		return cities;
	}
	
	public List<AreaPojo> getAreas()
	{
		List<AreaPojo> areas = (List<AreaPojo>)getHibernateTemplate().find("from AreaPojo");
		return areas;
	}
	
	public List<AreaPojo> getAreasById(Integer cityid)
	{
		List<AreaPojo> areas = (List<AreaPojo>)getHibernateTemplate().find("from AreaPojo where cityId=?",cityid);
		return areas;
	}
}
