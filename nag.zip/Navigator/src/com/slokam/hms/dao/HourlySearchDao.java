package com.slokam.hms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.pojo.HourlySearchpojo;
import com.slokam.hms.util.MyRowMapper;
import com.slokam.hms.util.VehicalRowMapper;

public class HourlySearchDao extends JdbcDaoSupport{

	
	public List<HourlySearchpojo> hourlysearch(int k)
	
	{
		System.out.println("dao");
		String qry1="select type from vehical where id=?";
		List<VehicleEntity> ve=getJdbcTemplate().query(qry1, new Object[]{k}, new VehicalRowMapper());
		VehicleEntity vpojo=ve.get(0);
		int t=vpojo.getType();
		System.out.println(vpojo.getType());
			
		
		String qry="select v.number,vt.name,l.date,l.month,l.year,l.Latitude,l.Longitude,l.hour,l.minit,l.second,l.speed from LiveData l join vehical v join vehicaltype vt on l.VehicleID=v.id  and v.type=vt.id where v.id=? and vt.id=?";
		List<HourlySearchpojo> hlist=getJdbcTemplate().query(qry,new Object[]{k,t},new MyRowMapper());
		
		return hlist;
	}
}
