package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.pojo.VehiclesEntity;

public class VehicalDao extends HibernateDaoSupport {
	
	public List<VehiclesEntity> getVihical(int id)
	{
		
		if(id==90)
		{
			System.out.println(id);
			List<VehiclesEntity> vlist=getHibernateTemplate().find("from VehiclesEntity");/*sas*/
			return vlist;
		}else
		{
		List<VehiclesEntity> vlist=getHibernateTemplate().find("from VehiclesEntity where branch=?",id);
		return vlist;
		}
	}

}
