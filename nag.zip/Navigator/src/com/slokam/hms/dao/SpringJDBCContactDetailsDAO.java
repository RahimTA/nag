package com.slokam.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.slokam.hms.mapper.ContactDetailsMapper;
import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.util.DBUtil;

public class SpringJDBCContactDetailsDAO {
	
	@Autowired
	private DataSource ds = null;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void setDs(DataSource ds) {
		this.ds = ds;
		//this.jdbcTemplate = new JdbcTemplate(ds);
		
	}
    

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	public void saveContactDetails(ContactPojo pojo )
	{
		
			String qry ="insert into " +
					"contactDetails(firstName,middleName, " +
					" lastname,email,city,mobile,landline, " +
					" startupcomp) values(?,?,?,?,?,?,?,?)";
			this.jdbcTemplate.update(qry,
					
					new Object[]{pojo.getFirstName(),pojo.getMiddleName(),
					pojo.getLastName(),pojo.getEmail(),pojo.getCity(),pojo.getMobileNumber(),
					pojo.getLandlineNumber(),pojo.getStartupComp()}
			);
		   
		   
		
	}
	
	public List<ContactPojo> searchAllContactDetails()
	{
		String qry = "SELECT * FROM contactdetails";
		List<ContactPojo> list = this.jdbcTemplate.query(qry,new ContactDetailsMapper());
		return list;
	}
	
	public ContactPojo  searchByIdContactDetails(String id)
	{
		String qry = "SELECT * FROM contactdetails where id=?";
		ContactPojo pojo = this.jdbcTemplate.queryForObject(qry,new Object[]{id}, new ContactDetailsMapper());
  	    return pojo;	
	}
	public void updateContactDetails(ContactPojo pojo )
	{
		
		String qry = " update  contactDetails set" +
					" firstName=? , middleName=?, lastname=?,email=?," +
					" city=?,mobile=?,landline=?, startupcomp=? " +
					"where id=?";
		
	   this.jdbcTemplate.update(qry,new Object[]{pojo.getFirstName(),
				pojo.getMiddleName(),
				pojo.getLastName(),pojo.getEmail(),pojo.getCity(),
				pojo.getMobileNumber(),
				pojo.getLandlineNumber(),pojo.getStartupComp(),pojo.getId()});
	
		
	}
}
