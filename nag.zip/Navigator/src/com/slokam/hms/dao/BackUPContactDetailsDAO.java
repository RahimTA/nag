package com.slokam.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.util.DBUtil;

public class BackUPContactDetailsDAO {
	
	@Autowired
	private DataSource ds = null;
	
	public void setDs(DataSource ds) {
		this.ds = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}
    
	private JdbcTemplate jdbcTemplate;
	

	

	public void saveContactDetails(ContactPojo pojo )
	{
		Connection con=null;
		PreparedStatement ps=null;
		try {
			/* Class.forName("com.mysql.jdbc.Driver");
	     	   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sjp","root","root");
			*/ 
			//con = DBUtil.getConnection();
			con= ds.getConnection();
			ps = con.prepareStatement("insert into " +
					"contactDetails(firstName,middleName, " +
					" lastname,email,city,mobile,landline, " +
					" startupcomp) values(?,?,?,?,?,?,?,?)");
		     ps.setString(1, pojo.getFirstName());
		     ps.setString(2, pojo.getMiddleName());
		     ps.setString(3, pojo.getLastName());
		     ps.setString(4, pojo.getEmail());
		     ps.setString(5, pojo.getCity());
		     ps.setString(6, pojo.getMobileNumber());
		     ps.setString(7, pojo.getLandlineNumber());
		     ps.setString(8, pojo.getStartupComp());
		     ps.executeUpdate();
		    
			}/* catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally{
			
			 try{
				 if(ps!=null)
					 ps.close();
				 if(con!=null)
					 con.close();
			 }
			 catch(SQLException e)
			 {
				e.printStackTrace();
			 }
		}
		
	}
	
	public List<ContactPojo> searchAllContactDetails()
	{
		Connection con=null;
		PreparedStatement ps=null;
		List<ContactPojo> list = new ArrayList<ContactPojo>();
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("SELECT * FROM contactdetails ");
		    ResultSet rs = ps.executeQuery();
		    while(rs.next())
		    {
		    	ContactPojo pojo = new ContactPojo();
		    	pojo.setId(rs.getString("id"));
		    	pojo.setCity(rs.getString("city"));
		    	pojo.setEmail(rs.getString("email"));
		    	pojo.setFirstName(rs.getString("firstname"));
		    	pojo.setLandlineNumber(rs.getString("landline"));
		    	pojo.setLastName(rs.getString("lastname"));
		    	pojo.setMiddleName(rs.getString("middlename"));
		    	pojo.setMobileNumber(rs.getString("mobile"));
		    	pojo.setStartupComp(rs.getString("startupcomp"));
		    	list.add(pojo);
		    }
		    
		    
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally{
			
			 try{
				 if(ps!=null)
					 ps.close();
				 if(con!=null)
					 con.close();
			 }
			 catch(SQLException e)
			 {
				e.printStackTrace();
			 }
		}
	 return list;	
	}
	
	public ContactPojo  searchByIdContactDetails(String id)
	{
		Connection con=null;
		PreparedStatement ps=null;
		ContactPojo pojo = null;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("SELECT * FROM contactdetails where id=?");
			ps.setString(1, id);
		    ResultSet rs = ps.executeQuery();
		    if(rs.next())
		    {
		    	pojo = new ContactPojo();
		    	pojo.setId(rs.getString("id"));
		    	pojo.setCity(rs.getString("city"));
		    	pojo.setEmail(rs.getString("email"));
		    	pojo.setFirstName(rs.getString("firstname"));
		    	pojo.setLandlineNumber(rs.getString("landline"));
		    	pojo.setLastName(rs.getString("lastname"));
		    	pojo.setMiddleName(rs.getString("middlename"));
		    	pojo.setMobileNumber(rs.getString("mobile"));
		    	pojo.setStartupComp(rs.getString("startupcomp"));
		    	
		    }
		    
		    
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally{
			
			 try{
				 if(ps!=null)
					 ps.close();
				 if(con!=null)
					 con.close();
			 }
			 catch(SQLException e)
			 {
				e.printStackTrace();
			 }
		}
	 return pojo;	
	}
	public void updateContactDetails(ContactPojo pojo )
	{
		Connection con=null;
		PreparedStatement ps=null;
		try {
			/* Class.forName("com.mysql.jdbc.Driver");
	     	   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sjp","root","root");
			*/ 
			//con = DBUtil.getConnection();
			con= ds.getConnection();
			ps = con.prepareStatement(" update  contactDetails set" +
					" firstName=? , middleName=?, lastname=?,email=?," +
					" city=?,mobile=?,landline=?, startupcomp=? " +
					"where id=? ");
			
		     ps.setString(1, pojo.getFirstName());
		     ps.setString(2, pojo.getMiddleName());
		     ps.setString(3, pojo.getLastName());
		     ps.setString(4, pojo.getEmail());
		     ps.setString(5, pojo.getCity());
		     ps.setString(6, pojo.getMobileNumber());
		     ps.setString(7, pojo.getLandlineNumber());
		     ps.setString(8, pojo.getStartupComp());
		     ps.setString(9, pojo.getId());
		     
		     ps.executeUpdate();
		    
			}/* catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally{
			
			 try{
				 if(ps!=null)
					 ps.close();
				 if(con!=null)
					 con.close();
			 }
			 catch(SQLException e)
			 {
				e.printStackTrace();
			 }
		}
		
	}
}
