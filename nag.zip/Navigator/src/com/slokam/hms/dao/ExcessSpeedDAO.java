package com.slokam.hms.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.slokam.hms.mapper.ExcessSpeedReportMapper;
import com.slokam.hms.pojo.ExcessSpeedPojo;
import com.slokam.hms.pojo.ExcessSpeedReportPojo;
import com.slokam.hms.service.ExcessSpeedService;

public class ExcessSpeedDAO extends JdbcDaoSupport
{
	
	public List<ExcessSpeedReportPojo> exReport(ExcessSpeedPojo expojo)
	{

	String qry = "SELECT v.number , vt.name , L.latitude , L.Longitude ,  L.speed , L.date , L.month , L.year ,  L.hour , L.minit , L.second   FROM LiveData L join vehical v on L.VehicleID = v.id join vehicaltype vt on L.VehicleID = vt.id where L.VehicleID = ? ";
	System.out.println(expojo.getVehicles());
	List<ExcessSpeedReportPojo> list = this.getJdbcTemplate().query(qry ,new Object[]{/*expojo.getSpeedLimit() , */expojo.getVehicles()} , new ExcessSpeedReportMapper());
	return list;
	}
}
