package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.screenpojo.ContactPojo;

public class ContactDetailsDAO extends HibernateDaoSupport{
	
	public void saveContactDetails(ContactPojo pojo )
	{
		
		
		   /*Session session = this.factory.openSession();
		    Transaction tx = session.beginTransaction();
		      session.save(pojo);
		    tx.commit();
		   
		   session.close();
		   */
		
		getHibernateTemplate().save(pojo);
		   
		
	}
	
	public List<ContactPojo> searchAllContactDetails()
	{
		
		List<ContactPojo> list = (List<ContactPojo>) getHibernateTemplate().find("from ContactPojo");
		return list;
	}
	
	public ContactPojo  searchByIdContactDetails(String id)
	{
		String qry = " FROM ContactPojo where id=?";
		List<ContactPojo> list = (List<ContactPojo>) getHibernateTemplate().find(qry,id);
		return list.get(0);	
	}
	public void updateContactDetails(ContactPojo pojo )
	{
	   getHibernateTemplate().update(pojo);
	}
}
