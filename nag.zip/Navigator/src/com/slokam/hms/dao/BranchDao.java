package com.slokam.hms.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.taglibs.standard.tag.common.core.SetSupport;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.pojo.BranchEntity;
import com.slokam.hms.pojo.BranchPojo;
import com.slokam.hms.pojo.VehiclePojo;


public class BranchDao extends HibernateDaoSupport{
	
	public List<BranchEntity> getBrancheshr()
	{
		List<BranchEntity> blist=(List<BranchEntity>)getHibernateTemplate().find("from BranchEntity");
		return blist;
	}
	
	
	public List<VehiclePojo> getVehicleshr(Integer branchid)
	{
		
		List<VehiclePojo> vehicles = (List<VehiclePojo>)getHibernateTemplate().find("from vehiclePojo where  branch=?",branchid);
		//System.out.println(vehicles);
		return vehicles;
	}
	
	public List<BranchPojo> getBranches()
	{
		List<BranchPojo> branches = (List<BranchPojo>)getHibernateTemplate().find("from BranchPojo");
		System.out.println(branches);
		return branches;
	}
	
	
	public List<VehiclePojo> getVehicles(Integer branchid)
	{
		
		List<VehiclePojo> vehicles = (List<VehiclePojo>)getHibernateTemplate().find("from VehiclePojo where branch=?" , branchid);
		//System.out.println(vehicles);
		return vehicles;
	}
	
	/*public List<VehicleInfoPojo> getVehicleInfo()
	{
		
		List<VehicleInfoPojo> vehicleinfo = (List<VehicleInfoPojo>)getHibernateTemplate().find("from VehicleInfoPojo");
		//System.out.println(vehicles);
		return vehicleinfo;
	}*/
	
	
	
}
