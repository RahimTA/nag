package com.slokam.hms.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.slokam.hms.entity.AddressEntityPojo;
import com.slokam.hms.entity.CityEntity;
import com.slokam.hms.entity.CountryEntity;
import com.slokam.hms.entity.StateEntity;
import com.slokam.hms.entity.UserEntity;
import com.slokam.hms.service.AddUserService;


public class UserDao extends HibernateDaoSupport {
	
	
	@Autowired
	AddUserService adduserservice=null;
	
	public void setAdduserservice(AddUserService adduserservice) {
		this.adduserservice = adduserservice;
	}

	public void saveUserDetails(UserEntity userEntity)
		{
			getHibernateTemplate().save(userEntity);
		}

	
	public List<CountryEntity> getCountry()
	{
		  
		List<CountryEntity> list=getHibernateTemplate().find("from CountryEntity");
			  return list;
	}
	
	
	public List<CityEntity> getCity()
	{
		List<CityEntity> list=getHibernateTemplate().find("from CityEntity");
		return list;
	}
	
	
	public List<StateEntity> getState()
	{
		List<StateEntity> list=getHibernateTemplate().find("from StateEntity");
		return list;
	}
	


 public List<UserEntity> getUserDetails()
 {
	 List<UserEntity> userDetails=(List<UserEntity>)getHibernateTemplate().find("from UserEntity");
	 return userDetails;
 }
	
	
}
