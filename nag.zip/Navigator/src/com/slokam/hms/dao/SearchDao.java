package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.pojo.SearchEntity;


public class SearchDao extends HibernateDaoSupport{
	
	
	public List<SearchEntity> searchAll()
	{
		List<SearchEntity> slist=getHibernateTemplate().find("from SearchEntity");
		return slist;
	}

}
