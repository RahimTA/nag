package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.slokam.hms.entity.DeviceEntity;
import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.screenpojo.DevicePojo;

public class DeviceDao extends HibernateDaoSupport{
	public void insertDeviceData(DeviceEntity dentity){
		System.out.println("in insertdao");
		getHibernateTemplate().save(dentity);
	}

	public List<DeviceEntity> searchResult()
	{
		List<DeviceEntity> list = (List<DeviceEntity>) getHibernateTemplate().find("from DeviceEntity");
		DeviceEntity entity=(DeviceEntity)list.get(0);
		return list;
	}
}
