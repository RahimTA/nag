package com.slokam.hms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.entity.VehiclePojoEntity;
import com.slokam.hms.screenpojo.CityPojo;
import com.slokam.hms.screenpojo.VehiclePojo;
import com.slokam.hms.screenpojo.VehicleTypePojo;

public class VehicleDao extends HibernateDaoSupport{
	
	
public void addVehicle(VehiclePojoEntity entity){
		
		getHibernateTemplate().save(entity);
		
	}


public List<VehicleTypePojo>  getVehicleType(){
	List<VehicleTypePojo> vehicles=(List<VehicleTypePojo>)getHibernateTemplate().find("from VehicleTypePojo");
   return vehicles;
}


public List<VehiclePojo> getVehicleByBranch(String branchType){
	   List<VehiclePojo> list=getHibernateTemplate().find("from VehiclePojo where barnch=?",branchType);
		  return list;
		}



	public List<VehicleEntity> getNumbers()
	{
		
		List<VehicleEntity> numbers = (List<VehicleEntity>)getHibernateTemplate().find("from VehicleEntity");
		VehicleEntity number=(VehicleEntity)numbers.get(0);
		System.out.println("vehicle entity pojo::"+number.getVehicalNumber());
		return numbers;
	}
	
	public List<VehiclePojoEntity> getVehicleDetails(){
		List<VehiclePojoEntity> vehicaldetails=(List<VehiclePojoEntity>)getHibernateTemplate().find("from VehiclePojoEntity");
		return vehicaldetails;
	}
	
}
