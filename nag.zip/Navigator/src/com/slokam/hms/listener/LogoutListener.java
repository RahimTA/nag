package com.slokam.hms.listener;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.slokam.hms.controller.TestController;
import com.slokam.hms.screenpojo.LoginPojo;

/**
 * Application Lifecycle Listener implementation class LogoutListener
 *
 */
public class LogoutListener implements HttpSessionListener {

    /**
     * Default constructor. 
     */
    public LogoutListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent arg0) {
        System.out.println("session Created");
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent arg0) {
    	
    	 ArrayList<String>  data = TestController.userList;
    	 String user = ((LoginPojo)arg0.getSession().getAttribute("user") ).getUserName();
    	 data.remove(user);
    	 System.out.println("session Destroyed");
    }
	
}
