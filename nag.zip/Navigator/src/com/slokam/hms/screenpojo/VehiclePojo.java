package com.slokam.hms.screenpojo;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;



public class VehiclePojo {
	
	@NotEmpty
	@NotNull
	private String vehicleInfo;
	@NotEmpty
	@NotNull
	private String vehicleNo;
	@NotEmpty
	@NotNull
	private String branchType;
	@NotEmpty
	@NotNull
	private String vehicleType;
	
	public String getVehicleInfo() {
		return vehicleInfo;
	}
	public void setVehicleInfo(String vehicleInfo) {
		this.vehicleInfo = vehicleInfo;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getBranchType() {
		return branchType;
	}
	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	

}
