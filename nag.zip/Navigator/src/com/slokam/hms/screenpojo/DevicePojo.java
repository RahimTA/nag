package com.slokam.hms.screenpojo;

import org.hibernate.validator.constraints.NotEmpty;

public class DevicePojo {
	
    private Integer id;
    @NotEmpty
	private Integer productId;
	private String manufacturedBy;
	private String sim;
	private String firmVersion;
	private Integer phoneNumber;
	private String imei;
	private String productModel;
	private String firmName;
	private String firmDescription;
	private String vehicalNumber;
	

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	

		public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	
	public String getManufacturedBy() {
		return manufacturedBy;
	}
	public void setManufacturedBy(String manufacturedBy) {
		this.manufacturedBy = manufacturedBy;
	}
	
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	
	
	public String getFirmVersion() {
		return firmVersion;
	}
	public void setFirmVersion(String firmVersion) {
		this.firmVersion = firmVersion;
	}
	
	
	public Integer getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	
  
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	

	public String getFirmDescription() {
		return firmDescription;
	}
	public void setFirmDescription(String firmDescription) {
		this.firmDescription = firmDescription;
	}
	
	
	public String getVehicalNumber() {
		return vehicalNumber;
	}
	public void setVehicalNumber(String vehicalNumber) {
		this.vehicalNumber = vehicalNumber;
	}



}
