package com.slokam.hms.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.slokam.hms.dao.ContactDetailsDAO;
import com.slokam.hms.screenpojo.ContactPojo;
public class ContactDAOTest {

	public static void main1(String[] args) {
		ContactDetailsDAO dao = null;
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet-test.xml");
	
		dao = (ContactDetailsDAO) context.getBean("dao");
		ContactPojo contactPojo = new ContactPojo();
		contactPojo.setCity("hyd");
		contactPojo.setEmail("sdfs");
		contactPojo.setFirstName("sdfs");
		contactPojo.setLandlineNumber("sdfs");
		contactPojo.setLastName("sdfs");
		contactPojo.setMiddleName("sdfs");
		contactPojo.setMobileNumber("sdfs");
		contactPojo.setStartupComp("sdfs");
		dao.saveContactDetails(contactPojo);
		
		
		
	}
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet-test.xml");
		
		ContactDetailsDAO dao = (ContactDetailsDAO) context.getBean("dao");
		
		List<ContactPojo> list = dao.searchAllContactDetails();
		
		for (ContactPojo contactPojo : list) {
			
		   System.out.println(contactPojo.getCity());	
		   System.out.println(contactPojo.getCity());
		   System.out.println( contactPojo.getFirstName());
		   System.out.println( contactPojo.getMiddleName());
		   System.out.println( contactPojo.getLastName());
		   System.out.println(  contactPojo.getEmail());
		   System.out.println( contactPojo.getCity());
		   System.out.println( contactPojo.getMobileNumber());
		   System.out.println(contactPojo.getLandlineNumber());
		   System.out.println( contactPojo.getStartupComp());
		}
	}
}
