package com.slokam.hms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.screenpojo.LatLongPojo;
@Controller
public class HistoryController {
	static public  int  counter =0; 
	public static List<LatLongPojo> list = new  ArrayList<LatLongPojo>();
	static
		{
		LatLongPojo  lat1 = new LatLongPojo("17.457115", "78.379841");
		LatLongPojo  lat2 = new LatLongPojo("17.435288", "78.448087");
		LatLongPojo  lat3 = new LatLongPojo("17.431399", "78.413186");
		LatLongPojo  lat4 = new LatLongPojo("17.418214", "78.437905");
		LatLongPojo  lat5 = new LatLongPojo("17.411048", "78.462421");
		LatLongPojo  lat6 = new LatLongPojo("17.481917", "78.329415");
		list.add(lat1);
		list.add(lat2);
		list.add(lat3);
		list.add(lat4);
		list.add(lat5);
		list.add(lat6);
		}
	


										
	@RequestMapping(value="/trackingHistory.html")
	public @ResponseBody String  dispayHistory(HttpServletRequest request){
		 
		
		if(counter==6)
			counter=0;
		counter++;
		request.setAttribute("dataObject", list.get(counter));
         
	return list.get(counter).toString();
}
	/*public static void main(String[] args) {
		HistoryController hcs = new HistoryController();
		hcs.dispayHistory();
		System.out.println(alist.get(0).toString());
		
	}*/
}
