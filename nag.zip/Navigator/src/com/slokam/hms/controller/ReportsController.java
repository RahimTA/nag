package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.screenpojo.CalculatorPojo;
@Controller
public class ReportsController {

	@RequestMapping(value="/reports.html")
	public ModelAndView dispayCalc()
	{
		return new ModelAndView("reports");
	}
}
