package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.dao.CityDAO;
import com.slokam.hms.dao.ContactDetailsDAO;
import com.slokam.hms.screenpojo.AreaPojo;
import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.screenpojo.LoginPojo;

@Controller
public class ContactDetailsController {
	
	@Autowired 
	private CityDAO citydao;
	
	
	public void setCitydao(CityDAO citydao) {
		this.citydao = citydao;
	}
	/*@Autowired
	private ContactDetailsDAO dao = null;
 	
	public void setDao(ContactDetailsDAO dao) {
		this.dao = dao;
	}*/

	/*@RequestMapping(value="/displaContact.html")
	public ModelAndView displaContact(HttpServletRequest req)
	{
	  
	   	return new ModelAndView("contact","pojo",new ContactPojo());
	}*/
	
	/*@RequestMapping(value="/getContact.html")
	public ModelAndView getContact(String id,HttpServletRequest req)
	{
		
		String role = ((LoginPojo)req.getSession().getAttribute("user")).getRole();
		if(role==null || !role.equals("admin"))
		{
			return new ModelAndView("login","pojo",new LoginPojo());
		}
		
		//ContactPojo pojo = dao.searchByIdContactDetails(id);
		return new ModelAndView("contact","pojo",pojo);
	}*/
	/*@RequestMapping(value="/saveContact.html")
	public ModelAndView saveContact(ContactPojo pojo)
	{
		String city = pojo.getCity().trim();
		//city = city.replaceAll(",", "");
		city = city.charAt(0)+"";
		pojo.setCity(city);
		
		if(pojo.getId()==null || pojo.getId().trim().length()==0)
		   dao.saveContactDetails(pojo);
		else
			dao.updateContactDetails(pojo);
		
		return new ModelAndView("contact","pojo",pojo);
	}*/
	
	/*@RequestMapping(value="/searchAllContact.html")
	public ModelAndView searchAllContact(ContactPojo pojo,HttpServletRequest req)
	{
		List<ContactPojo> list = dao.searchAllContactDetails();
		req.setAttribute("searchData", list);
		return new ModelAndView("contactSearch","pojo",pojo);
	}
	@RequestMapping(value="/getAreasByCityId.html")
	public ModelAndView getAreasByCityId(ContactPojo pojo,HttpServletRequest req)
	{
		String city = pojo.getCity().trim();
		//city = city.replaceAll(",", "");
		city = city.charAt(0)+"";
		pojo.setCity(city);
		List<AreaPojo> areas = citydao.getAreasById(Integer.parseInt(city));
		req.setAttribute("areas", areas);
		return new ModelAndView("contact","pojo",pojo);
	}*/
}
