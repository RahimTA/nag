package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Test2 {

	@RequestMapping(value="/testtest.html")
	public ModelAndView test2Mthod1()
	{
		System.out.println("Hello i am in test2Mthod1()");
		
		return new ModelAndView("testtest");
	}
}
