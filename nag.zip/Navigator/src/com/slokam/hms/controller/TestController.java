package com.slokam.hms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.tiles.request.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.dao.CityDAO;
import com.slokam.hms.dao.LoginDAO;
import com.slokam.hms.screenpojo.AreaPojo;
import com.slokam.hms.screenpojo.CityPojo;
import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.screenpojo.LoginPojo;



@Controller
public class TestController {
	public static ArrayList<String> userList = new ArrayList<String>(); 
	
	@Autowired
	private CityDAO citydao = null;
	
	public void setCitydao(CityDAO citydao) {
		this.citydao = citydao;
	}

	@Autowired
	private LoginDAO logindao = null;

    public void setLogindao(LoginDAO logindao) {
		this.logindao = logindao;
	}

	@RequestMapping(value="/test.html")
	public ModelAndView test()
	{
		System.out.println("Hello");
		return new ModelAndView("login","pojo",new LoginPojo());
	}
	
	@RequestMapping(value="/login.html")
	public ModelAndView login( LoginPojo pojo,HttpServletRequest req)
	{
		
		if(userList.contains(pojo.getUserName()))
		{
			 return new ModelAndView("login","pojo",new LoginPojo());
		}
		
		LoginPojo pojoFromDao = logindao.login(pojo);
		System.out.println("I am in login");
		
		
		if(pojoFromDao!=null)
		{
		  userList.add(pojo.getUserName());
	      req.getSession().setAttribute("user", pojoFromDao); 
	   
	      if(req.getServletContext().getAttribute("cities") ==null)
	      {
		      List<CityPojo> cities = citydao.getCities();
		      req.getServletContext().setAttribute("cities", cities);
		       
		      List<AreaPojo> areas =(List<AreaPojo>) citydao.getAreas();
		      req.getServletContext().setAttribute("areas", areas);
	      }
		  return new ModelAndView("contact","pojo",new ContactPojo());
		}
		else
		{
		 return new ModelAndView("login","pojo",new LoginPojo());
		}
	}
	@RequestMapping(value="/regis.html")
	public ModelAndView regis()
	{
		System.out.println("I am in registration:");
		LoginPojo login= new LoginPojo();
		/*login.setDob("12/12/12");
		login.setName("A");
		login.setPassword("P");
		login.setUserName("U");*/
		return new ModelAndView("regis","login", login);
	}
	
	
	@RequestMapping(value="/saveRegis.html")
	public ModelAndView saveRegis(LoginPojo pojo,HttpServletRequest request)
	{
		//System.out.println(pojo.getName());
		System.out.println(pojo.getPassword());
		//System.out.println(pojo.getDob());
		System.out.println(pojo.getUserName());
		
		pojo.setUserName(pojo.getUserName()+"Hello");
		//save data in db.
		request.setAttribute("msg", "Succefully Registred.");
		
		return new ModelAndView("regis","login", pojo);
	}
	
	@RequestMapping(value="/logout.html")
	public ModelAndView logout(HttpServletRequest req)
	{
	    String userName= ((LoginPojo)req.getSession().getAttribute("user")).getUserName();
		userList.remove(userName);
		req.getSession().invalidate();
		return new ModelAndView("login","pojo", new LoginPojo());
	}
}
