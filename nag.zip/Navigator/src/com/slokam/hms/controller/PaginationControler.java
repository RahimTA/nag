package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.slokam.hms.pojo.HourlySearchpojo;
import com.slokam.hms.pojo.hoursreportpojo;
import com.slokam.hms.pojo.hoursreportpojo;



@Controller
public class PaginationControler {
	
	


	@RequestMapping(value="/hrpagination.html")
	public ModelAndView pagination(HttpServletRequest req,hoursreportpojo pojo)
	{
		String disable=null;
		List<HourlySearchpojo> biglist=(List<HourlySearchpojo>)req.getSession().getAttribute("biglist");
		int pageno=(Integer)req.getSession().getAttribute("pageno");
		pageno++;
		int pagesize=(Integer)req.getSession().getAttribute("pagesize");
		int startno=(pageno-1)*pagesize;
		int endno=pageno*pagesize;
		//if(endno>bigList.size());
			
		if(endno>=biglist.size()){
			endno=biglist.size();
			disable="yes";
		}
		System.out.println((biglist.subList(startno, endno)).size());
		List<HourlySearchpojo> sublist=biglist.subList(startno, endno);
		req.setAttribute("hpojo",sublist);
		req.getSession().setAttribute("pageno",pageno);
		req.getSession().setAttribute("pagesize",pagesize);
		req.setAttribute("disable",disable);
		return new ModelAndView("hours","hoursreportpojo",pojo);
	}
	

	

}
