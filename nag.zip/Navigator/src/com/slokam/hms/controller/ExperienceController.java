package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ExperienceController {

	@RequestMapping(value="/displayExperience.html")
	public ModelAndView displayExperience()
	{
		return new ModelAndView("experience");
	}
	
	
}
