package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class DailyReportController {


		@RequestMapping(value="/reportDaily.html")
		public ModelAndView dispayCalc()
		{
			return new ModelAndView("daily");
		}

}
