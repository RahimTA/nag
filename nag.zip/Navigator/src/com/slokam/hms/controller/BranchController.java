package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.screenpojo.ContactPojo;

@Controller
public class BranchController {

	@RequestMapping(value="/displayBranch.html")
	public ModelAndView displayBranch( )
	{
		return new ModelAndView("branch","pojo",new ContactPojo());
	}
	
}
