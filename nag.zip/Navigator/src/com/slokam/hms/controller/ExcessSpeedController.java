package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.dao.BranchDao;
import com.slokam.hms.pojo.BranchPojo;
import com.slokam.hms.pojo.ExcessSpeedPojo;
import com.slokam.hms.pojo.ExcessSpeedReportPojo;
import com.slokam.hms.pojo.VehiclePojo;
import com.slokam.hms.service.ExcessSpeedService;
@Controller
public class ExcessSpeedController {


	@Autowired
	private ExcessSpeedService exSpeedService = null;
	
	public void setExSpeedService(ExcessSpeedService exSpeedService) {
		this.exSpeedService = exSpeedService;
	}

	@Autowired
	private BranchDao bdao;

	public void setBranchdao(BranchDao branchdao) {
		this.bdao = branchdao;
	}

	@RequestMapping(value="/excessReports.html")
	public ModelAndView excessSpeed(ExcessSpeedPojo expojo , HttpServletRequest req)
	{
		List<BranchPojo> list = bdao.getBranches();
		req.getSession().setAttribute("disbranch", list);
		
		return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
	}
	
	
	
	@RequestMapping(value="/getVehiclesByBranchId.html")
	public ModelAndView excessSpeed1(ExcessSpeedPojo pojo , HttpServletRequest req)
	{
		/*List<BranchPojo> list = branchdao.getBranches();
		req.getSession().setAttribute("disbranch", list);*/
		String branchId = pojo.getBranch().trim();
		System.out.println(branchId);
		branchId = branchId.charAt(0)+"";
		System.out.println("sriiii");
		
		List<VehiclePojo> list1 = bdao.getVehicles(Integer.parseInt(branchId));
		req.setAttribute("disvehicle", list1);
		//System.out.println(list);
		return new ModelAndView("excess","expojo",pojo);
	}
	
	/*@RequestMapping(value="/excessspeed.html")
	public ModelAndView excessSpeedsub(ExcessSpeedPojo epojo1 , HttpServletRequest req)
	{
		System.out.println(epojo1);
		List<ExcessSpeedPojo> list = new ArrayList<ExcessSpeedPojo>();
		list.add(epojo1);
		req.setAttribute("dis", list);
		List<VehicleInfoPojo> bigList = branchdao.getVehicleInfo();
		req.getSession().setAttribute("bigList", bigList);
		List<VehicleInfoPojo> subList = bigList.subList(0, 3);
		req.setAttribute("vehicleinfo", subList);
		req.getSession().setAttribute("pageNo", 1);
		return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
	}*/

	/*@RequestMapping(value="/pagination.html")
	public ModelAndView excessPagination(ExcessSpeedPojo epojo1 , HttpServletRequest req)
	{
		
		int pageNew = (Integer) req.getSession().getAttribute("pageNo");
		if(pageNew >= 2)
		{
			req.setAttribute("disablep", "yes");
		}
		pageNew++;
		System.out.println(pageNew);
		int startNo = (pageNew*3)-3;
		int endNo = pageNew*3;
		
		List<VehicleInfoPojo> bigList = (List<VehicleInfoPojo>)req.getSession().getAttribute("bigList");
		if(endNo > bigList.size())
		{
			endNo = bigList.size();
			req.setAttribute("disable", "yes");
		}
		List<VehicleInfoPojo> subList = bigList.subList(startNo, endNo);
		req.getSession().setAttribute("vehicleinfo",subList);
		req.getSession().setAttribute("pageNo",pageNew);
		
			
		return new ModelAndView("excess","expojo",new ExcessSpeedPojo());*/
	
	
	
	@RequestMapping(value="/excessReportsdisplay.html")
	public ModelAndView excessSpeedReport(ExcessSpeedPojo expojo , HttpServletRequest req)
	{
		System.out.println(expojo.getVehicles());
		System.out.println("in search controller");
		List<ExcessSpeedReportPojo> bigList = exSpeedService.display(expojo);
		if(bigList.size() == 0 || bigList == null)
		{
			return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
		}
		req.getSession().setAttribute("bigList", bigList);
		List<ExcessSpeedReportPojo> subList = bigList.subList(0, 3);
		req.setAttribute("display", subList);
		req.getSession().setAttribute("pageNo", 1);
		return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
	}
	
	@RequestMapping(value="/expagination.html")
	public ModelAndView excessPagination(String prev , ExcessSpeedPojo epojo1 , HttpServletRequest req)
	{
		
        int pageNew = (Integer) req.getSession().getAttribute("pageNo");
		
		/*if(pageNew >= 2)
		{
			req.setAttribute("disablep", "yes");
			
		}*/
	
		/*if(prev.equalsIgnoreCase("previous"))
		{
			pageNew--;
			System.out.println(pageNew);
			int startNo = (pageNew*3)-3;
			int endNo = pageNew*3;
			
			List<ExcessSpeedReportPojo> bigList = (List<ExcessSpeedReportPojo>)req.getSession().getAttribute("bigList");
			if(startNo <= 0)
			{
				endNo = bigList.size();
				req.setAttribute("disablep", "yes");
			}
			List<ExcessSpeedReportPojo> subList = bigList.subList(startNo, endNo);
			req.getSession().setAttribute("display",subList);
			req.getSession().setAttribute("pageNo",pageNew);
			
				
			return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
			
			
		}*/
		
		pageNew++;
		System.out.println(pageNew);
		int startNo = (pageNew*3)-3;
		int endNo = pageNew*3;
		
		List<ExcessSpeedReportPojo> bigList = (List<ExcessSpeedReportPojo>)req.getSession().getAttribute("bigList");
		if(endNo > bigList.size())
		{
			endNo = bigList.size();
			req.setAttribute("disable", "yes");
		}
		List<ExcessSpeedReportPojo> subList = bigList.subList(startNo, endNo);
		req.getSession().setAttribute("display",subList);
		req.getSession().setAttribute("pageNo",pageNew);
		
			
		return new ModelAndView("excess","expojo",new ExcessSpeedPojo());
	}
}
