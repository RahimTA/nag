package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.screenpojo.CalculatorPojo;

@Controller
public class CalculatorControler {

	@RequestMapping(value="/add.html")
	public ModelAndView dispayCalc()
	{
		return new ModelAndView("add","pojo",new CalculatorPojo());
	}
	
	@RequestMapping(value="/performAdd.html")
	public ModelAndView add(CalculatorPojo pojo)
	{
		pojo.setResult( pojo.getValue1()+pojo.getValue2());
		return new ModelAndView("add","pojo",pojo);		
	}
}
