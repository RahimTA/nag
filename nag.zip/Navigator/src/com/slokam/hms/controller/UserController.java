package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.entity.AddressEntityPojo;
import com.slokam.hms.entity.CityEntity;
import com.slokam.hms.entity.CountryEntity;
import com.slokam.hms.entity.StateEntity;
import com.slokam.hms.entity.UserEntity;
import com.slokam.hms.screenpojo.UserScreenPojo;
import com.slokam.hms.service.AddUserService;

@Controller
public class UserController {
	
	@Autowired
	private AddUserService addUserService;
	
	

	@RequestMapping(value="/displayUser.html")
	public ModelAndView displayBranch(HttpServletRequest request)
	{
		// Taken for Country dropDown
				List<CountryEntity> countrylist=addUserService.getCountry();
				request.getSession().setAttribute("countries", countrylist);
			
				// Taken for Country dropDown
				List<CityEntity> citylist=addUserService.getCity();
				request.getSession().setAttribute("cities", citylist);
			
				// Taken for State dropDown
				List<StateEntity> statelist=addUserService.getState();
				request.getSession().setAttribute("states", statelist);
				
				//Search Data
				List<UserEntity> Biglist=addUserService.getUserDetails();
				request.getSession().setAttribute("usersdetails",Biglist);
				System.out.println("hello");
				System.out.println(Biglist.get(0).getName());
				System.out.println(Biglist.get(0).getEmail());
				System.out.println(Biglist.get(0).getMobile());
				
				
				/*//for Pagination
			    List<UserEntity> subList=Biglist.subList(0, 5);
			    request.setAttribute("searchData", subList);
			    request.getSession().setAttribute("biglist",Biglist);
			    */
  			

		
		return new ModelAndView("users","userscreenpojo",new UserScreenPojo());
	}
	
	@RequestMapping(value="/saveUser.html")
	public ModelAndView saveUser(Model model, @Valid @ModelAttribute("user") UserEntity user, BindingResult result,UserScreenPojo pojo)
	{

	/*	if (result.hasErrors()){
			 return new ModelAndView("users","userscreenpojo",new UserScreenPojo());
		    }
		    else {
		   	 addUserService.addUser(pojo);
		    }*/
		
		 addUserService.addUser(pojo);
		
		  return new ModelAndView("users","userscreenpojo",new UserScreenPojo());
	}
	
	/*@RequestMapping(value="/pagination.html")
	public ModelAndView pagination(HttpServletRequest request)
	{
		    List<UserEntity> Biglist=addUserService.getUserDetails();
		    request.getSession().getAttribute("Biglist");
		    List<UserEntity> subList=Biglist.subList(0, 5);
		    request.setAttribute("searchData", subList);
		   
		
		return new ModelAndView("users","userscreenpojo",new UserScreenPojo());
	}*/
	
	
	
}
