package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TrackingController {

	@RequestMapping(value="/displayTracking.html")
	public ModelAndView dispayTracking()
	{
		return new ModelAndView("tracking");
	}
}
