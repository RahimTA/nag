package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.dao.VehicleDao;
import com.slokam.hms.entity.VehiclePojoEntity;
import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.screenpojo.VehiclePojo;
import com.slokam.hms.screenpojo.VehicleTypePojo;
import com.slokam.hms.service.AddVehicleService;


@Controller
public class VehicleController {
	
	@Autowired
	VehicleDao vehicledao=null;
	
	public void setVehicledao(VehicleDao vehicledao) {
		this.vehicledao = vehicledao;
	}
    @Autowired
	private AddVehicleService addVehicleService;

    public void setAddVehicleService(AddVehicleService addVehicleService) {
		this.addVehicleService = addVehicleService;
	}

		@RequestMapping(value="/displayVehicle.html")
		 ModelAndView displayBranch(VehiclePojo vehiclePojo,HttpServletRequest request)
		{ 
		 List<VehicleTypePojo>  vehicles= addVehicleService.getVehicleType(); 
		 request.getSession().setAttribute("vehicles", vehicles);  
		 List<VehiclePojoEntity> vehiclesdetails=addVehicleService.getVehicleDetails();
		 request.getSession().setAttribute("biglist", vehiclesdetails);
		 List<VehiclePojoEntity> vehiclesdetails1=vehiclesdetails.subList(0, 5);
			request.getSession().setAttribute("vehiclesdetails", vehiclesdetails1);
			request.getSession().setAttribute("pageNo",1);
		return new ModelAndView("vehicle","pojo",new ContactPojo());
		}
	
		@RequestMapping(value="/addVehicle.html")
		public ModelAndView addVehicle(@Valid VehiclePojo vehiclePojo,BindingResult result,HttpServletRequest request,Model model){
			
			if (result.hasErrors()) {
				return new ModelAndView("vehicle","pojo",new ContactPojo());
			}
			addVehicleService.addVehicle(vehiclePojo);
			
			VehiclePojo pojo = new VehiclePojo();
			model.addAttribute(pojo);
			
			return new ModelAndView("vehicle", "vehiclePojo" ,pojo);
 }

		@RequestMapping(value="/pagination.html")
		public ModelAndView pagination(VehiclePojo vehiclePojo,HttpServletRequest request){
			int pageNo=(Integer)request.getSession().getAttribute("pageNo");
			pageNo++;
			List<VehiclePojoEntity> biglist=(List<VehiclePojoEntity>)request.getSession().getAttribute("biglist");
			int startNo=(pageNo-1)*5;
			int endNo=pageNo*5;
			
			if(endNo>=biglist.size()){
				request.getSession().setAttribute("lastPage","yes");
				endNo=biglist.size();
			}
		   List<VehiclePojoEntity> vehicledetails=biglist.subList(startNo,endNo);
		   request.setAttribute("vehiclesdetails", vehicledetails);
		   request.getSession().setAttribute("pageNo", pageNo);
		   return new ModelAndView("vehicle","pojo",new ContactPojo());
		}

		
		@RequestMapping(value="/priviousPage.html")
		public ModelAndView priviousPagination(HttpServletRequest request,VehiclePojo vehiclePojo) {
			int pageNo=(Integer)request.getSession().getAttribute("pageNo");
			pageNo--;
			List<VehiclePojoEntity> biglist=(List<VehiclePojoEntity>)request.getSession().getAttribute("biglist");
			int startNo=(pageNo-1)*5;
			int endNo=pageNo*5;	
			List<VehiclePojoEntity> vehicledetails=biglist.subList(startNo, endNo);
			request.getSession().setAttribute("vehiclesdetails", vehicledetails);
			 request.getSession().setAttribute("pageNo", pageNo);
			   return new ModelAndView("vehicle","pojo",new ContactPojo());
		}
}




