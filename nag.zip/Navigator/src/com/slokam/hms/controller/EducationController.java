package com.slokam.hms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EducationController {
	
	@RequestMapping(value="/displayEducation.html")
	public ModelAndView displayEducation()
	{
		
		return new ModelAndView("education");
	}

}
