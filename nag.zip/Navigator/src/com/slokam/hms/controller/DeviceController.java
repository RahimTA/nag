package com.slokam.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.dao.DeviceDao;
import com.slokam.hms.dao.VehicleDao;
import com.slokam.hms.entity.DeviceEntity;
import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.screenpojo.CityPojo;
import com.slokam.hms.screenpojo.ContactPojo;
import com.slokam.hms.screenpojo.DevicePojo;
import com.slokam.hms.screenpojo.VehiclePojo;
import com.slokam.hms.service.DeviceService;

@Controller
public class DeviceController {
	
	@Autowired
	private DeviceService deviceservice=null;
	
	public void setDeviceservice(DeviceService deviceservice) {
		this.deviceservice = deviceservice;
	}
	
	@Autowired
	VehicleDao vehicledao=null;
	public void setVehicledao(VehicleDao vehicledao) {
		this.vehicledao = vehicledao;
	}
    	

	@RequestMapping(value="/displayDevice.html")
	public ModelAndView displayDevice( DevicePojo pojo,HttpServletRequest req) 
	{
	     List<DeviceEntity>  biglist=deviceservice.searchDeviceDetails(pojo);
	     List<DeviceEntity> sublist=biglist.subList(0,5);
	     System.out.println("i am in display controller");
		 req.setAttribute("searchData", sublist);
		 req.getSession().setAttribute("biglist",biglist);
		 req.getSession().setAttribute("pageNo", 1);
		 deviceservice.getVechicleNumbers(req);
		return new ModelAndView("device","pojo",new DevicePojo());
	}
		
	@RequestMapping(value="/insertDeviceDetails.html")
	    public ModelAndView insertDeviceDetails(DevicePojo screenpojo, DevicePojo pojo, BindingResult result){
		deviceservice.insertDetails(screenpojo);
		return new ModelAndView("device","pojo",screenpojo);
	}
     
  /*	@RequestMapping(method = RequestMethod.GET)
	public String displayDevice(ModelMap model) {
        System.out.println("in displaydevice()");
		model.addAttribute("pojo", new DevicePojo());
		return "AddDevice";
 
	}*/
	
	@RequestMapping(value="/devicePagination.html")
	public ModelAndView pagination(Integer pageNo,HttpServletRequest request){
		System.out.println("I am in  pagination controller");
		pageNo=(Integer)request.getSession().getAttribute("pageNo");
		pageNo++;
		int startNo=(pageNo-1)*5;
		int endNo=pageNo*5;
    	List<DeviceEntity>  biglist=(List<DeviceEntity>)request.getSession().getAttribute("biglist");
        if(endNo >=biglist.size()){
	    	endNo=biglist.size();
	    	request.setAttribute("lastpage","yes");
	    }
	    List<DeviceEntity>  sublist=biglist.subList(startNo,endNo);
	    request.getSession().setAttribute("pageNo", pageNo);
	    request.getSession().setAttribute("searchData", sublist);
	    
	    return new ModelAndView("device","pojo",new DevicePojo());
	}
	
	/*@RequestMapping(value="/paginationprevious.html")
	public ModelAndView paginationprevious(Integer pageNo,HttpServletRequest request){
		pageNo=(Integer)request.getSession().getAttribute("pageNo");
		int startNo=(pageNo-1)*5;
		int endNo=pageNo*5;
		System.out.println(startNo);
		System.out.println(endNo);
		List<DeviceEntity>  biglist=(List<DeviceEntity>)request.getSession().getAttribute("biglist");
	    List<DeviceEntity>  sublist=biglist.subList(startNo,endNo);
	    pageNo--;
	    System.out.println(pageNo);
	    request.getSession().setAttribute("pageNo", pageNo);
	    request.getSession().setAttribute("searchData", sublist);
		 return new ModelAndView("device","pojo",new DevicePojo());
		
	}*/
	}

