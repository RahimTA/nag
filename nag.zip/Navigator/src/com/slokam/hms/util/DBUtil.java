package com.slokam.hms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

public class DBUtil {
	private static InitialContext context =null;
	private static DataSource ds = null;
	

	public static Connection  getConnection()
	{
		Connection con =null;
			try {
				if(ds==null)
				{
				 context = new InitialContext();
				 ds = (DataSource)context.lookup("java:comp/env/jdbc/vtrack");
				}
				con = ds.getConnection();
			
			} catch (NamingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
	}
	
	public static void createLocalDataSource()
	{
		BasicDataSource ds = new  BasicDataSource();
		
	}
}
