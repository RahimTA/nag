package com.slokam.hms.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.pojo.HourlySearchpojo;

public class VehicalRowMapper implements org.springframework.jdbc.core.RowMapper<VehicleEntity>{

	public VehicleEntity mapRow(ResultSet rs, int arg1) throws SQLException {
		
		VehicleEntity ve=new VehicleEntity();
		ve.setType(rs.getInt("type"));
		return ve;
	}

}
