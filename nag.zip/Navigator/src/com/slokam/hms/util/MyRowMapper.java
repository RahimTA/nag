package com.slokam.hms.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.tree.RowMapper;
import javax.swing.tree.TreePath;

import org.springframework.jdbc.core.RowMapperResultSetExtractor;

import com.slokam.hms.pojo.HourlySearchpojo;

public class MyRowMapper implements org.springframework.jdbc.core.RowMapper<HourlySearchpojo>{

	public HourlySearchpojo mapRow(ResultSet rs, int arg1) throws SQLException {
		
		HourlySearchpojo hpojo=new HourlySearchpojo();
		hpojo.setVehicalid(rs.getString("v.number"));
		hpojo.setVehicalname(rs.getString("vt.name"));
		hpojo.setDate(rs.getString("l.date"));
		hpojo.setMonth(rs.getString("l.month"));
		hpojo.setYear(rs.getString("year"));
		hpojo.setHour(rs.getString("hour"));
		hpojo.setMinit(rs.getString("minit"));
		hpojo.setSecond(rs.getString("second"));
		hpojo.setLatitude(rs.getString("Latitude"));
		hpojo.setLongitude(rs.getString("Longitude"));
		hpojo.setSpeed(rs.getString("speed"));
		
		
		
		return hpojo;
	}

	
	

}
