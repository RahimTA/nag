package com.slokam.hms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="vehical")
public class VehiclePojoEntity {


		
		private String vehicleInfo;		
		private String vehicleNo;		
		private String branchType;		
		private String vehicleType;
		
		@Column(name="description")
		public String getVehicleInfo() {
			return vehicleInfo;
		}
		public void setVehicleInfo(String vehicleInfo) {
			this.vehicleInfo = vehicleInfo;
		}
		@Id
		@Column(name="number")
		public String getVehicleNo() {
			return vehicleNo;
		}
		public void setVehicleNo(String vehicleNo) {
			this.vehicleNo = vehicleNo;
		}
		@Column(name="branch")
		public String getBranchType() {
			return branchType;
		}
		public void setBranchType(String branchType) {
			this.branchType = branchType;
		}
		@Column(name="type")
		public String getVehicleType() {
			return vehicleType;
		}
		public void setVehicleType(String vehicleType) {
			this.vehicleType = vehicleType;
		}
		
	

}
