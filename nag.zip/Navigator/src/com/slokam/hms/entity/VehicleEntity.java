package com.slokam.hms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="vehical")
public class VehicleEntity {
	
	    private Integer  id;
	    private Integer type;
	    private String description;
	    private String branch;
	    private String vehicalNumber;
	    
	    @OneToOne
	    @JoinColumn(name="vehicalNumber")
	    private DeviceEntity dentity;
	    
		
		/*public DeviceEntity getDentity() {
			return dentity;
		}*/
		public void setDentity(DeviceEntity dentity) {
			this.dentity = dentity;
		}
		@Id
	    @GeneratedValue
	    @Column(name="id")
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		
		
		
		@Column(name="type")
		public Integer getType() {
			return type;
		}
		public void setType(Integer type) {
			this.type = type;
		}
		
		@Column(name="description")
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		
		@Column(name="branch")
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		
		
		@Column(name="number")
		public String getVehicalNumber() {
			return vehicalNumber;
		}
		public void setVehicalNumber(String vehicalNumber) {
			this.vehicalNumber = vehicalNumber;
		}
		
		
}
