package com.slokam.hms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


    
	@Entity
	@Table(name="device")
	public class DeviceEntity {
		
	    private Integer id;
		private Integer productId;
		private String manufacturedBy;
		private String sim;
		private String firmVersion;
		private Integer phoneNumber;
		private String imei;
		private String productModel;
		private String firmName;
		private String firmDescription;
		private String vehicalNumber;
		
		@OneToOne(mappedBy="DeviceEntity")
        private VehicleEntity ventity;

	/*	public VehicleEntity getVentity() {
			return ventity;
		}*/
		public void setVentity(VehicleEntity ventity) {
			this.ventity = ventity;
		}
		@Column(name="id")
		@GeneratedValue
		@Id
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		
		@Column(name="ProductID")
			public Integer getProductId() {
			return productId;
		}

		public void setProductId(Integer productId) {
			this.productId = productId;
		}
		
		@Column(name="ManufacturedBy")
		public String getManufacturedBy() {
			return manufacturedBy;
		}
		public void setManufacturedBy(String manufacturedBy) {
			this.manufacturedBy = manufacturedBy;
		}
		
		@Column(name="SIMNO")
		public String getSim() {
			return sim;
		}
		public void setSim(String sim) {
			this.sim = sim;
		}
		
		@Column(name="FirmVersion")
		public String getFirmVersion() {
			return firmVersion;
		}
		public void setFirmVersion(String firmVersion) {
			this.firmVersion = firmVersion;
		}
		
		@Column(name="PhoneNumber")
		public Integer getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(Integer phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		
		@Column(name="IMEI")
		public String getImei() {
			return imei;
		}
		public void setImei(String imei) {
			this.imei = imei;
		}
		
	  @Column(name="ProductModel")
		public String getProductModel() {
			return productModel;
		}
		public void setProductModel(String productModel) {
			this.productModel = productModel;
		}
		@Column(name="FirmName")
		public String getFirmName() {
			return firmName;
		}
		public void setFirmName(String firmName) {
			this.firmName = firmName;
		}
		

		@Column(name="FirmDescription")
		public String getFirmDescription() {
			return firmDescription;
		}
		public void setFirmDescription(String firmDescription) {
			this.firmDescription = firmDescription;
		}
		
		@Column(name="number")		
		public String getVehicalNumber() {
			return vehicalNumber;
		}
		public void setVehicalNumber(String vehicalNumber) {
			this.vehicalNumber = vehicalNumber;
		}

	}
