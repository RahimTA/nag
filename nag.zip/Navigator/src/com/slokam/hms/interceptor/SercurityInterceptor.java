package com.slokam.hms.interceptor;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.hms.screenpojo.LoginPojo;


public class SercurityInterceptor implements HandlerInterceptor {

	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		System.out.println("afterCompletion");
		
	}

	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2, ModelAndView arg3) throws Exception {
		System.out.println("postHandle");
		
	}

	public boolean preHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2) throws Exception {
		System.out.println("preHandle");
		
		List<String> list = new ArrayList<String>();
		
		list.add("/WebApp/test.html");
		list.add("/WebApp/login.html");
		
		LoginPojo loginpojo = (LoginPojo) arg0.getSession().
				 getAttribute("user") ;
		 
		String currentreq =arg0.getRequestURI();
		 
		 if(!list.contains(currentreq))
		 {
		    if(loginpojo==null)
			 {
		    	  arg0.getRequestDispatcher("/test.html").forward(arg0, arg1);
			      return false;
			 }
		 }  
		  return true;
	}

	
	
}
