package com.slokam.hms.servises;

import java.beans.DesignMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.slokam.hms.dao.HourlySearchDao;
import com.slokam.hms.pojo.HourlySearchpojo;
import com.slokam.hms.pojo.SearchEntity;

public class HourService {
	
	
	@Autowired
	private HourlySearchDao hdao;
	
	
	public void setHdao(HourlySearchDao hdao) {
		this.hdao = hdao;
	}
	public List<HourlySearchpojo> hsearch(int k)
	{
		
		
		List<HourlySearchpojo> hlist=hdao.hourlysearch(k);
		List<HourlySearchpojo> hlist1=new ArrayList<HourlySearchpojo>();
		
		HourlySearchpojo hpojo;
		for(int i=0;hlist.size()>i;i++)
		{
			
		 hpojo=hlist.get(i);
		
		hpojo.getVehicalid();									/*VEHICALNUMBER*/
		
		hpojo.getVehicalname();									/*VEHICALTYPE*/
		String h=hpojo.getHour();
		String m=hpojo.getMinit();
		String s=hpojo.getSecond();
		hpojo.setTime(h+":"+m+":"+s);														/*TIME*/
		
		String latitude=hpojo.getLatitude();
		String langitude=hpojo.getLongitude();
		hpojo.setStartlocation(latitude+","+langitude);										/*STARTLOCATION*/
		
		
		int speed=Integer.parseInt(hpojo.getSpeed());
		int hour=Integer.parseInt(h);
		int distance=speed*hour;     							/*DISTANCE*/
		hpojo.setDistance(distance);
		String totime=Integer.parseInt(h)+1+"";
		hpojo.setTime2(totime+":"+m+":"+s);						/*TIME2*/
		HourlySearchpojo hlpojo=hlist.get((hlist.size())-1);
		String llatitude=hlpojo.getLatitude();
		String llangitude=hlpojo.getLongitude();
		/*DecimalFormat df=new DecimalFormat("0.00");
		df.setMaximumFractionDigits(2);
		String llatitude=df.format(Float.parseFloat(hlpojo.getLatitude()));
		
		String llangitude=df.format(Float.parseFloat((hlpojo.getLongitude())));
		*/
		hpojo.setEndlocation(llatitude+","+llangitude);						/*ENDLOCATION*/
		
		/*System.out.println(hpojo.getVehicalid());
		System.out.println(hpojo.getVehicalname());
		System.out.println(hpojo.getTime());
		System.out.println(hpojo.getStartlocation());
		System.out.println(hpojo.getDistance());
		SearchEntity searchent=new SearchEntity();*/
		hlist1.add(hpojo);	
		
		}
		
		return hlist1;
	}
	

}
