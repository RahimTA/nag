package com.slokam.hms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.slokam.hms.dao.UserDao;
import com.slokam.hms.entity.AddressEntityPojo;
import com.slokam.hms.entity.CityEntity;
import com.slokam.hms.entity.CountryEntity;
import com.slokam.hms.entity.StateEntity;
import com.slokam.hms.entity.UserEntity;
import com.slokam.hms.screenpojo.UserScreenPojo;

public class AddUserService {

	@Autowired
	UserDao userdao=null;

	public void setUserdao(UserDao userdao) {
		this.userdao = userdao;
	}
	
	
	
	public void addUser(UserScreenPojo userscreenpojo)
	{
	
	AddressEntityPojo AddressEntityPojo = new AddressEntityPojo();
		AddressEntityPojo.setAddress(userscreenpojo.getAddress());
		AddressEntityPojo.setCity(userscreenpojo.getCity());
		AddressEntityPojo.setCountry(userscreenpojo.getCountry());
		AddressEntityPojo.setState(userscreenpojo.getState());
		
	List<AddressEntityPojo> addressList = new ArrayList<AddressEntityPojo>();
		addressList.add(AddressEntityPojo);
	
	UserEntity userEntity=new UserEntity();
		userEntity.setSurName(userscreenpojo.getSurName());
		userEntity.setEmail(userscreenpojo.getEmail());
		userEntity.setMobile(userscreenpojo.getMobile());
		userEntity.setName(userscreenpojo.getName());
		userEntity.setPassword(userscreenpojo.getPassword());
		userEntity.setRegiDate(userscreenpojo.getRegiDate());
		userEntity.setUserId(userscreenpojo.getUserId());
		
		AddressEntityPojo.setUser(userEntity);
		userEntity.setAddress(addressList);
		
	userdao.saveUserDetails(userEntity);
	
		
	}
	
	public List<CountryEntity> getCountry()
	{
		List<CountryEntity> list=userdao.getCountry();
		return list;
	}

	
	public List<CityEntity> getCity()
	{
		List<CityEntity> list=userdao.getCity();
		return list;
	}
	

	public List<StateEntity> getState()
	{
		List<StateEntity> list=userdao.getState();
		return list;
	}
	
	public List<UserEntity> getUserDetails()
	{
		List<UserEntity> userDetails=userdao.getUserDetails();
		return userDetails;
	}
	
	
}
