package com.slokam.hms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.slokam.hms.dao.ExcessSpeedDAO;
import com.slokam.hms.pojo.ExcessSpeedPojo;
import com.slokam.hms.pojo.ExcessSpeedReportPojo;

public class ExcessSpeedService 
{
    @Autowired
    private ExcessSpeedDAO exdao = null;

	public void setExdao(ExcessSpeedDAO exdao) {
		this.exdao = exdao;
	}
    
	public List<ExcessSpeedReportPojo> display(ExcessSpeedPojo expojo)
	{
		
		System.out.println(expojo.getVehicles());
		/* String fromdate = expojo.getFromDate();
		 String todate = expojo.getToDate();
		
		 String[] parts = fromdate.split("/");
		 String[] parts1 = todate.split("/");
		 
		 String dates = parts[0];
		 String months = parts[1];
		 String years = parts[2];
		 String date1 = parts1[0];
		 String month1 = parts1[1];
		 String year1 = parts1[2];*/
		 
		 List<ExcessSpeedReportPojo> list = exdao.exReport(expojo);
		List<ExcessSpeedReportPojo> list1 = new ArrayList<ExcessSpeedReportPojo>();
		ExcessSpeedReportPojo pojo = new ExcessSpeedReportPojo();
		for(int i=0;i<=list.size()-1;i++)
		{
		String vehicleno = list.get(i).getVehicleNO();
		String vehicletype = list.get(i).getVehicleType();
		String speed = list.get(i).getSpeed();
		String date = list.get(i).getDate();
		String month = list.get(i).getMonth();
		String year = list.get(i).getYear();
		String hour = list.get(i).getHour();
		String minit = list.get(i).getMinit();
		String second = list.get(i).getSecond();
		String loc1 = list.get(i).getLatitude();
		String loc2 = list.get(i).getLatitude();
		String newTime = hour+":"+minit+":"+second;
		String newDate = date+":"+month+":"+year;
		String newLoc = loc1+","+loc2;
		pojo.setDate(date);
		pojo.setMonth(month);
		pojo.setYear(year);
		pojo.setHour(hour);
		pojo.setMinit(minit);
		pojo.setSecond(second);
		pojo.setLatitude(loc1);
		pojo.setLongitude(loc2);
		pojo.setSpeed(speed);
		pojo.setVehicleNO(vehicleno);
		pojo.setVehicleType(vehicletype);
		pojo.setNewDate(newDate);
		pojo.setNewTime(newTime);
		pojo.setNewLoc(newLoc);
		
		list1.add(pojo);
		/*System.out.println(newDate);
		System.out.println(newTime);
		System.out.println(newLoc);*/
		}
		
		return list1;
	}
	
}
