package com.slokam.hms.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.slokam.hms.dao.VehicleDao;
import com.slokam.hms.entity.VehiclePojoEntity;
import com.slokam.hms.screenpojo.VehiclePojo;
import com.slokam.hms.screenpojo.VehicleTypePojo;


public class AddVehicleService {
	@Autowired
	VehicleDao dao=null;

	public void setDao(VehicleDao dao) {
		this.dao = dao;
	}
	
	 

	  
	  
	   public void addVehicle(VehiclePojo sreenPojo){
		  
		   VehiclePojoEntity entity = new VehiclePojoEntity();
		   entity.setBranchType(sreenPojo.getBranchType());
		   entity.setVehicleInfo(sreenPojo.getVehicleInfo());
		   entity.setVehicleNo(sreenPojo.getVehicleNo());
		   entity.setVehicleType(sreenPojo.getVehicleType());
		   dao.addVehicle(entity);
		   
		   
	  }
		public List<VehicleTypePojo> getVehicleType(){
			
			List<VehicleTypePojo> vehicles=dao.getVehicleType();
			return vehicles;
		}
		
		public List<VehiclePojoEntity> getVehicleDetails(){
			List<VehiclePojoEntity> vehicledetails=dao.getVehicleDetails();	
				return vehicledetails;
		
		}
		

}

