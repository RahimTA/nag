package com.slokam.hms.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.slokam.hms.dao.DeviceDao;
import com.slokam.hms.dao.VehicleDao;
import com.slokam.hms.entity.DeviceEntity;
import com.slokam.hms.entity.VehicleEntity;
import com.slokam.hms.screenpojo.DevicePojo;
import com.slokam.hms.screenpojo.VehiclePojo;

public class DeviceService {
	
	@Autowired
	private DeviceDao devicedao=null;

    public void setDevicedao(DeviceDao devicedao) {
		this.devicedao = devicedao;
	}
    
    @Autowired
	private VehicleDao vehicledao=null;

	public void setVehicledao(VehicleDao vehicledao) {
		this.vehicledao = vehicledao;
	}


	public  void insertDetails(DevicePojo screenpojo){
    	 DeviceEntity dentity=new DeviceEntity();
    	 
    	 dentity.setProductId(screenpojo.getProductId());
    	 dentity.setManufacturedBy(screenpojo.getManufacturedBy());
    	 dentity.setSim(screenpojo.getSim());
    	 dentity.setFirmVersion(screenpojo.getFirmVersion());
    	 dentity.setPhoneNumber(screenpojo.getPhoneNumber());
    	 dentity.setImei(screenpojo.getImei());
    	 dentity.setProductModel(screenpojo.getProductModel());
    	 dentity.setFirmName(screenpojo.getFirmName());
    	 dentity.setFirmDescription(screenpojo.getFirmDescription());
    	 dentity.setVehicalNumber(screenpojo.getVehicalNumber());

    	 devicedao.insertDeviceData(dentity);	
    }
       public void getVechicleNumbers(HttpServletRequest req){
    	   List<VehicleEntity> numbers = vehicledao.getNumbers();
 	      req.getServletContext().setAttribute("numbers", numbers);
       }
    
       public List<DeviceEntity> searchDeviceDetails(DevicePojo pojo)
       {
    	   List<DeviceEntity> list = devicedao.searchResult();
   		   return list;
       }

}
