-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.30-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema vtrack
--

CREATE DATABASE IF NOT EXISTS vtrack;
USE vtrack;

--
-- Definition of table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Address` varchar(45) NOT NULL,
  `city` int(10) unsigned NOT NULL,
  `state` int(10) unsigned NOT NULL,
  `country` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;


--
-- Definition of table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE `branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;


--
-- Definition of table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

/*!40000 ALTER TABLE `city` DISABLE KEYS */;
/*!40000 ALTER TABLE `city` ENABLE KEYS */;


--
-- Definition of table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

/*!40000 ALTER TABLE `country` DISABLE KEYS */;
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


--
-- Definition of table `device`
--

DROP TABLE IF EXISTS `device`;
CREATE TABLE `device` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProductID` varchar(45) NOT NULL,
  `ManufacturedBy` varchar(45) NOT NULL,
  `SIMNO` varchar(45) NOT NULL,
  `FirmVersion` varchar(45) NOT NULL,
  `PhoneNumber` int(10) unsigned NOT NULL,
  `IMEI` varchar(45) NOT NULL,
  `ProductModel` int(10) unsigned NOT NULL,
  `FirmName` varchar(45) NOT NULL,
  `FirmDescription` varchar(45) NOT NULL,
  `vehicalId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device`
--

/*!40000 ALTER TABLE `device` DISABLE KEYS */;
/*!40000 ALTER TABLE `device` ENABLE KEYS */;


--
-- Definition of table `devicemodel`
--

DROP TABLE IF EXISTS `devicemodel`;
CREATE TABLE `devicemodel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devicemodel`
--

/*!40000 ALTER TABLE `devicemodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `devicemodel` ENABLE KEYS */;


--
-- Definition of table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE `state` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

/*!40000 ALTER TABLE `state` DISABLE KEYS */;
/*!40000 ALTER TABLE `state` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `sirname` varchar(45) NOT NULL,
  `userId` varchar(45) NOT NULL,
  `mobile` int(10) unsigned NOT NULL,
  `regisDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `vehical`
--

DROP TABLE IF EXISTS `vehical`;
CREATE TABLE `vehical` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(45) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `description` varchar(45) NOT NULL,
  `branch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehical`
--

/*!40000 ALTER TABLE `vehical` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehical` ENABLE KEYS */;


--
-- Definition of table `vehicaltype`
--

DROP TABLE IF EXISTS `vehicaltype`;
CREATE TABLE `vehicaltype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `area`;
CREATE TABLE `area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `cityId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` (`id`,`name`,`cityId`) VALUES 
 (1,'GandhiNagar',1),
 (2,'SRNagar',1),
 (3,'KPHB',1),
 (4,'Kajipet',8),
 (5,'AVC',8);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;


--
-- Definition of table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` (`id`,`name`) VALUES 
 (1,'Hyd'),
 (2,'Atp'),
 (3,'Gutur'),
 (4,'Nellore'),
 (5,'Vizag'),
 (6,'Prakasam'),
 (7,'tenali'),
 (8,'varangal'),
 (9,'Kadiri');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;


--
-- Definition of table `contactdetails`
--

DROP TABLE IF EXISTS `contactdetails`;
CREATE TABLE `contactdetails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(45) NOT NULL,
  `MiddleName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `City` varchar(4500) NOT NULL,
  `Mobile` varchar(45) NOT NULL,
  `LandLine` varchar(45) NOT NULL,
  `StartUpComp` varchar(45) NOT NULL,
  `Area` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactdetails`
--

/*!40000 ALTER TABLE `contactdetails` DISABLE KEYS */;
INSERT INTO `contactdetails` (`id`,`FirstName`,`MiddleName`,`LastName`,`Email`,`City`,`Mobile`,`LandLine`,`StartUpComp`,`Area`) VALUES 
 (5,'asdf','asdf','asdf','asdf','0','asf','asdf','2',0),
 (6,'slo','asdf','asdf','asdf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','435434','34543543','1',0),
 (7,'slo123','slo123','slo123','slo123','0,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','slo123','slo123','1',0),
 (8,'asdf','asdf','asdf','sadf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','asfd','asf','1',0),
 (9,'asdf','asdf','asdf','asdf','Visakhapatnam~andhra pradesh~India~Hyderabad~3 ~Rest of A.P.~Andhra Pradesh~50,','sdaf','asdf','1',0),
 (10,'asdffsfa','asdf','asdf','asdf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Visakhapatnam~andhra pradesh~India~Hyderabad~3 ~Rest of A.P.~Andhra Pradesh~50,','sdaf','asdf','1',0),
 (11,'ASDasd','asdfasdf','asdf','asdf','8','asdf','asdf','1',4),
 (12,'ADasfdasdf','AD','AD','AD','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Anantapur~andhra pradesh~India~Hyderabad~3 ~Rest of A.P.~Andhra Pradesh~50,AD','AD','AD','1',0),
 (13,'Preview Profile ','Preview Profile ','Preview Profile ','Preview Profile sdf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','47234324','Preview Profile ','2',0),
 (14,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',0),
 (15,'bhada','asdas','dfsd','jasdas','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','fs','sdfsd','1',0),
 (16,'bhada','asdas','dfsd','','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','fs@gsdc.com','sdfsd','1',0),
 (17,'MiddleName','First Name','First Name','First Name','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','779993454353454','First Name','0',0),
 (18,'hgfhfh','fasedfsadf','asdf','asdfsadf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','asdfsdaf','asdfdsa','1',0),
 (19,'asdf','asdf','asdf','asdf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','asd','asdf','2',0),
 (20,'SearchAll ','SearchAll ','SearchAll ','SearchAll ','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','SearchAll ','SearchAll ','2',0),
 (21,'4566','asdf','asdf','sdf','Hyderabad~andhra pradesh~India~Hyderabad~1 ~hyderabad~Andhra Pradesh~50,','asdf','asdf','1',0),
 (22,'523','523','523','523','1','523','523','2',2),
 (23,'qwer','qwer','qwer','qwer','4,','wer','qwer','1',2),
 (24,'NewRecord','NewRecord','','NewRecord','1,1','NewRecord','NewRecord','1',2),
 (25,'First Name:','First Name:','First Name:','First Name:','1','First Name:','First Name:','2',2),
 (26,'zXc','eeee','xczv','ZXC','1','xcv','zxcv','1',1),
 (27,'','','','','0','','','0',0),
 (28,'','','','','0','','','0',0),
 (29,'','','','','0','','','0',0),
 (30,'','','','','0','','','0',0),
 (31,'','','','','0','','','0',0),
 (32,'','','','','0','','','0',0),
 (33,'','','','','0','','','0',0),
 (34,'','','','','0','','','0',0),
 (35,'','','','','0','','','0',0),
 (36,'','','','','0','','','0',0),
 (37,'','','','','0','','','0',0),
 (38,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (39,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (40,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (41,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (42,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (43,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (44,'sdfs','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (45,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (46,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (47,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (48,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (49,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (50,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (51,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (52,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (53,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (54,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (55,'786','sdfs','sdfs','sdfs','hyd','sdfs','sdfs','sdfs',1),
 (56,'asdfasdf','asdfasdfasdf','asdf','asdf','8','sdf','asdf','1',4),
 (57,'getwtwt','asdf','asdfasd','asdfasdf','1','w3rerwer','asdfsaf','1',2),
 (58,'Name','Name','Name','Name','1','Name','Name','1',2),
 (59,'sdfg','dfg','sdf','fdgdfg','3','32242423','','0',0),
 (60,'U29nZW5jb24=','Middle ','Last ','Email ','1','23424','34535','1',3);
/*!40000 ALTER TABLE `contactdetails` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userName` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`id`,`userName`,`password`,`role`,`email`) VALUES 
 (1,'slokam','slokam','admin','unreddy.j2ee@gmail.com'),
 (2,'slostudent','slostudent','admin','upendra.kris@gmail.com');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Dumping data for table `vehicaltype`
--

/*!40000 ALTER TABLE `vehicaltype` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicaltype` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
