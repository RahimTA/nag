//ver 1.4 21022012 
// last modified : Rupesh Gawde
// modified date : 28-05-2013
// Remove function which are caliing /common/LookupRS.asp page
function CheckNM_RangeFields(oMinFieldName, oMaxFieldName, oMinDispName, oMaxDispName)   
{
/* 	Passing the Object Name of the Minimum & Maximum Object as parameters
	in that Sequence. This is applicable to Checking the Fields that are 
	to be Inputted in Range. 
	e.g. CheckNonMandatory(document.forms[0].txtMinAge, document.forms[0].txtMaxAge);
	- By Anil V.K.
*/
	if (oMinFieldName.value != "" ||  oMaxFieldName.value != "")
	{
		if (oMinFieldName.value == "")
		{
			alert("Please Enter the " + oMinDispName + " Value");
			oMinFieldName.focus();
			return false;
		}
	else
	{
		if (isNaN(oMinFieldName.value) || (parseFloat(oMinFieldName.value) < 0))
		{
			alert(oMinDispName + " Value has to be a Zero or Positive Number");
			oMinFieldName.focus();
			return false;
		}
	}

	if (oMaxFieldName.value == "")
	{
		alert("Please Enter the " + oMaxDispName);
		oMaxFieldName.focus();
		return false;
	}
	else
	{
		if (isNaN(oMaxFieldName.value) || (parseFloat(oMaxFieldName.value) < 0))
		{
			alert(oMaxDispName + " Value has to be a Zero or Positive Number");
			oMaxFieldName.focus();
			return false;
		}
	}

	if (parseFloat(oMinFieldName.value) > parseFloat(oMaxFieldName.value))
	{
		alert(oMinDispName + " Value Cannot be Greater than the " + oMaxDispName);
		oMinFieldName.focus();
		return false;
	}

	}
	
	return true;
	
}

////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////


function CheckNM_NumField(oNumField, oNumDispName)
/* 	This Function will help in Checking whether a value entered in a numeric field
	is a +ve Numeric Value
	- By Anil V.K.
*/

{
	if (oNumField.value != "")
	{
		if (isNaN(oNumField.value) || (parseFloat(oNumField.value) < 0)) 
		{
			alert(oNumDispName + " has to be zero or positive number.");
			oNumField.focus();
			return false;
		}
	}

}

////////////////////////////////////////////////////////////////////////////////////////////
function isBlank(val)
/* This Function will help in checking whether a value is null or space
	-By Surekha J.
*/
{
	for(var i=0;i<val.length;i++) 
	{
		if ((val.charAt(i)!=' ')) 
		{
			return false;
		}
	return true;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////
//Modification : Inserted some junk character into IsJunk function: Gade Jayshri. Date: 14/07/07
function IsEmpty(aTextField,DispNameField) 
/* This function will help in checking whether field is empty or not.
	if not empty, it will checking for invalid character & number
	-By Surekha J.
*/
{
   if ((aTextField.value.length==0) || (aTextField.value==null)) 
   {
		alert("Please enter "+DispNameField);
		aTextField.focus();
        return false;
   }
   else if ((aTextField.value.length > 0) || (aTextField.value!=""))
   {
	 if (isBlank(aTextField.value))
	 {
		alert("Please enter "+DispNameField);
		aTextField.focus();
        return false;
	 }	
	 // 'jayshri passing some extra junk character as parameter to IsJunkPresent	
	 else if(IsJunkPresent(aTextField.value,"@!&=+.<>?)}_{(#$%^*123456789~#'`:,;/\|")==true)	
	   {
			alert("Invalid character entered in "+DispNameField);
			aTextField.focus();
			return false;
	   }
	
   }
}  

////////////////////////////////////////////////////////////////////////////////////////////

function CheckZero_NumField(oNumField, oNumDispName)
/* 	This Function will help in Checking whether a value entered in a numeric field
	is a +ve Numeric Value
	- By Anil V.K.
*/

{
	if (oNumField.value != "")
	{
		if (isNaN(oNumField.value) || (parseFloat(oNumField.value) < 0) || (oNumField.value==0) ) 
		{
			alert(oNumDispName + " has to be positve number.");
			oNumField.focus();
			return false;
		}
	}

}

////////////////////////////////////////////////////////////////////////////////////////////

function IsJunkPresent(strPassed,strJunkBag)
{
/*	This function is used for Returning whether the Unwanted Characters appear in your
	string
	- By Rupali K.
*/

  var strJunk = "[" + strJunkBag + "]";
  var re = new RegExp(strJunk,"ig");
  var arr = re.exec(strPassed);
	if (arr!=null) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////

function CheckSingleValue(oFieldName, strFieldDisplayName)
{
/*	This function is used for returning whether the field passed has got only a single
	value not separated by Comma(s)
	This function expects the name of the field to be checked and the Field Name to be 
	displayed in the Error Message, if generated.
	-	By Anil V.K.
*/
	if (oFieldName.value != "")
	{
		if (IsJunkPresent(oFieldName.value,",") == true)
		{
			alert("You have to enter only one " + strFieldDisplayName );
			oFieldName.focus();
			return false;
		}
		else
		{
			return true;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////

function CheckLength(oFieldValue,totlen)
{
/* This function is used to restrict user from exceeding <totlen> characters in a textarea
   - By Rupali K.
*/
	    var ostr="";
	    ostr = new String(oFieldValue);	
		if (ostr.length > totlen)
		{
			return false;
		}
		return true;
}

///////////////////////////////////////////////////////////////////////////////////////////
function isPhoneNumber(s)
{
/*	This function is used for returning whether proper Phone Number has been entered
	- By Rupali K.
*/
	var numberexists=false;
    for (i = 0; i < s.length; i++)
    {   
        var c=s.charAt(i);
        if (c == " " || c == "(" || c == ")" || c == "-" || c == "+" || ((c >= "0") && (c <= "9")))
        {
          //treat above mentioned characters as valid characters
        }
        else
        {
            return false;
        }    
        if (i>0)
        {
          // if the character is not a digit i.e. a space or ( or ) or -
          if (!(c >= "0") && (c <= "9")) 
          {
			  var d=s.charAt(i-1);
			  // if two consecutive characaters are similar
			  if (c==d) return false;
			  // characters ( or ) cannot be consecutive to each other
		      if ((c == "(" || c == ")") && (d == "(" || d ==")")) return false;
          }
          else
          {
			  // at least one number exists	
	          numberexists=true;
          }
        }
    }
    if (numberexists==false) return false;
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////////

function isEmail (s)
{
/* 
 This function is used for returning whether proper Email Address has been entered
 Email address must be of form a@b.c -- in other words:
 there must be at least one character before the @
 there must be at least one character before and after the .
 the characters @ and . are both required
 - By Rupali K.
*/
    var cnt=0;
    var cntdot=0;
    // is s whitespace?
    for (i = 0; i < s.length; i++)
    {   
		var c=s.charAt(i);
        // Check that current character isn't whitespace.
        if (c == " ") return false;
		// Keep count of @
        if (c == "@") cnt=cnt+1;
        // Keep count of .
        if (c == ".") cntdot=cntdot+1;
        if (i>0) 
        {
          if (c == ".")
          {
			var d=s.charAt(i-1);
			// if consecutive dots
			if (d == ".") return false;
          }			
        }
    }
    
    // if @ count greater than 1 or is 0
    // if dot count is 0
    if (cnt>1 || cnt==0 || cntdot==0) return false;
    
    // there must be >= 1 character before @, so we
    // start looking at character position 1 
    // (i.e. second character)
    var i = 1;
    var sLength = s.length;

    // look for @
    while ((i < sLength) && (s.charAt(i) != "@"))
    { i++
    }

    if ((i >= sLength) || (s.charAt(i) != "@")) return false;
    else i += 2;

    // look for .
    while ((i < sLength) && (s.charAt(i) != "."))
    { i++
    }

    // there must be at least one character after the .
    if ((i >= sLength - 1) || (s.charAt(i) != ".")) return false;
    else return true;
}

////////////////////////////////////////////////////////////////////////////////////////////
/* This function will help for to do trim the field .
	-By Surekha J.
*/

function Trim(TRIM_VALUE){
if(TRIM_VALUE.length < 1){
return"";
}
TRIM_VALUE = RTrim(TRIM_VALUE);
TRIM_VALUE = LTrim(TRIM_VALUE);
if(TRIM_VALUE==""){
return "";
}
else{
return TRIM_VALUE;
}
} //End Function

function RTrim(VALUE){
var w_space = String.fromCharCode(32);
var v_length = VALUE.length;
var strTemp = "";
if(v_length < 0){
return"";
}
var iTemp = v_length -1;

while(iTemp > -1){
if(VALUE.charAt(iTemp) == w_space){
}
else{
strTemp = VALUE.substring(0,iTemp +1);
break;
}
iTemp = iTemp-1;

} //End While
return strTemp;

} //End Function

function LTrim(VALUE){
var w_space = String.fromCharCode(32);
if(v_length < 1){
return"";
}
var v_length = VALUE.length;
var strTemp = "";

var iTemp = 0;

while(iTemp < v_length){
if(VALUE.charAt(iTemp) == w_space){
}
else{
strTemp = VALUE.substring(iTemp,v_length);
break;
}
iTemp = iTemp + 1;
} //End While
return strTemp;
} //End Function
////////////////////////////////////////////////////////////////////////////////////////////

function SingleQuoteUpdate(DocumentForm)
{
/*	This function replaces the ( ' )-Single Quotes entered in the form with
	( � )-Chr(145) which is required
	- By Anil V.K.
*/
	var Str="";
	var RepChar="";
	var Re="";
	
	for (i=0;i<DocumentForm.length ;i++)
	{
		Re = /'/g;
		Str = DocumentForm.elements[i].value;
		if (Str != null)
		{
			DocumentForm.elements[i].value = Str.replace(Re,"�");	
		}
	}
}
 

////////////////////////////////////////////////////////////////////////////////////////////

function CheckSingleLocation(oCountry,oState,oCity)
{
/* Checking for dependencies of Resident Country, State & City
	- By Anil V.K.
*/

		// Checking if only one Country name has been entered
		if (CheckSingleValue(oCountry,"Country") == false)
		{
			return false;
		}

		// Checking if only one State name has been entered
		if (CheckSingleValue(oState,"State") == false)
		{
			return false;
		}

		// Checking if only one City name has been entered
		if (CheckSingleValue(oCity,"City") == false)
		{
			return false;
		}

// Check for Invalid Cities
	var InvCities="";
	InvCities = AcceptSingleLocations("CitiesOkay",oCountry,oState,oCity)
	
	if (InvCities != "")
	{
		if (confirm("City Name entered Does Not Match with the State Entered. Accept Anyway?\n" + InvCities ) != true)
		{
			oCity.focus();
			return false;
		}
	}


// Check for Invalid States
	var InvStates="";
	InvStates = AcceptSingleLocations("StatesOkay",oCountry,oState,oCity)
	
	if (InvStates != "")
	{
		if (confirm("State Name entered Does Not Match with the Country Entered. Accept Anyway?\n" + InvStates ) != true)
		{
			oState.focus();
			return false;
		}
	}

// Check for Invalid Countries
	var InvCountries="";
	InvCountries = AcceptSingleLocations("CountriesOkay",oCountry,oState,oCity)
	
	if (InvCountries != "")
	{
		alert("Country Name entered is incorrect. Cannot Proceed !!!");
		oCountry.focus();
		return false;
	}

}

////////////////////////////////////////////////////////////////////////////////////////////



function CheckMultipleLocations(oCountries,oStates,oCities)
{
/* Checking for dependencies of Preferred Countries, States & Cities
	- By Anil V.K.
*/

// Check for Invalid Countries
	var InvCountries="";
	InvCountries = AcceptLocations("CountriesOkay",oCountries,oStates,oCities)
	
	if (InvCountries != "")
	{
		alert("One or more Country Names entered are incorrect. Cannot Proceed !!!");
		oCountries.focus();
		return false;
	}
	

// Check for Invalid States
	var InvStates="";

	InvStates = AcceptLocations("StatesOkay",oCountries,oStates,oCities)
	
	if (InvStates != "")
	{
		if (confirm("One or more State Names entered are incorrect. Accept Anyway?\n" + InvStates ) != true)
		{
			oStates.focus();
			return false;
		}
	}

// Check for Invalid Cities
	var InvCities="";
	InvCities = AcceptLocations("CitiesOkay",oCountries,oStates,oCities)
	
	if (InvCities != "")
	{
		if (confirm("One or more City Names entered are incorrect. Accept Anyway?\n" + InvCities ) != true)
		{
			oCities.focus();
			return false;
		}
	}

}

////////////////////////////////////////////////////////////////////////////////////////////




/////////////////////////////////////////////////////////////////////////////////////////////
/*
By Sandip Hatkhamkar
Purpose :Validating MapjobidString for comma separated & numeric entry values.
Date : 14-11-2000.
StrFld1 : This parameter must contain the form field which is to be validated against comma & numeric characters.
StrFld2 : This parameter must contain the form field with respect to which the error is to be prompted to user.
frmName : Must contain the name of HTML Form element.
Elements : Must contain the count of rows in the HTML form.
for e.g ValidateMapJobIdString('mapJobIdString','ProfileId','F1',5)

*/

var i;
var fld=" ";
var invalid=1;
var strprofileId="";
var invalidchar="";
var firstChar="";
var lastChar="";

function ValidateMapJobIdString(StrFld1,StrFld2,frmName,Elements)
{

	for(j=1;j<=Elements;j++)
	{
			fld=document.forms[frmName].elements[StrFld1+j].value
			i=0;
			
			lastChar=document.forms[frmName].elements[StrFld1+j].value.substring(document.forms[frmName].elements[StrFld1+j].value.length-1)
						
			firstChar=document.forms[frmName].elements[StrFld1+j].value.substring(0,1)
			
	
		while(i<=document.forms[frmName].elements[StrFld1+j].value.length)
		{
						
		 if(!(isNaN(fld.charAt(i)))||(fld.charAt(i)==","))
		 {	
			//checking for commas in input string
				if((firstChar!="," )&&(lastChar!=","))
				{			
					if ((fld.substring(i,i-1)!=",") || (fld.substring(i,i+1)!=","))
					{
						null;
					}
					else
					{
						
						strprofileId=strprofileId +document.forms[frmName].elements[StrFld2+j].value + ","
				
						break;
		
					}
				
				}
				else		
				{		
						
					if(i==0)
					{
					
						strprofileId=strprofileId +document.forms[frmName].elements[StrFld2+j].value + ","
					
					}
				
				
				}		
			
		}
		else
		{
			
				invalidchar=invalidchar+document.forms[frmName].elements[StrFld2+j].value + ","
				break;
													
		}				
			
			i++;
		}
	
		
    }
  			
  			
	
  		if (strprofileId!="" && invalidchar!="")
		{
			
				strprofileId=strprofileId.substring(0,strprofileId.length-1);
				invalidchar=invalidchar.substring(0,invalidchar.length-1);
				alert("Incorrect entries found in Map jobs for profileId "+ strprofileId +"\nalso \nInvalid character in Map jobs for ProfileId " +invalidchar+"\nPlease enter again!");
				invalidchar="";
				strprofileId="";
				return false;
			
		}		
		else if(invalidchar!="") 
		{
			invalidchar=invalidchar.substring(0,invalidchar.length-1);
			alert("Invalid character in Map Jobs for ProfileId " +invalidchar+"\n Please enter again!");
			invalidchar="";		
			return false;
			
		}
		else if(strprofileId !="") 
		{
				strprofileId=strprofileId.substring(0,strprofileId.length-1)
				alert("Incorrect entries found in map jobs for profileId "+ strprofileId +"\n Please enter again!");
				strprofileId="";
				return false;
		}
		else if(fld!="")
		{	
				
				//document.forms[frmName].submit();				
				return true;
				
		}
			
  				

  
  }


/////////////////////////////////////////////////////////////////////////////////////////////

/* 
By Sandip Hatkhamkar
Date : 20-11-2000
Purpose : For redirecting to Asp page using browser(client side) not webserver.
Parameters
AspFile : Name of the Asp file to be redirected.
Ukey : Userkey for the UserId.
*/


function RedirectAsp(AspFile,Ukey)
{
window.location.href=AspFile+"?Ukey="+Ukey
}

/////////////////////////////////////////////////////////////////////////////////////////////

/* 
By Sandip Hatkhamkar
Date : 21-11-2000
Purpose : For validating Check Boxes for selection 
Parameters
ChkBox : Name of the Check Box.
FrmName : Name of the form element.
Elements : Total number of rows displayed in current page.
*/

var i=1;
var chkBoxChecked="";

function ValidateCheckBox(ChkBox,FrmName,Elements)
{

	for(i=1;i<=Elements;i++)
	{
		if(document.forms[FrmName].elements[ChkBox+i].checked==true && document.forms[FrmName].elements[ChkBox+i].value!="")
		{			
			chkBoxChecked=true;
			break;	
		}
		else
		{
			chkBoxChecked=false;						
		
		}
		
	}

		
		if(chkBoxChecked==true)
		{			
			//document.forms[FrmName].submit();			
			return true;
			
		}
		else 
		{
			alert("Please select atleast one item.")							
			return false;	
		}
		
}


////////////////////////////////////////////////////////////////////////////////////////////

/* added by Sandip.
Date : 29-11-2000
Purpose : For making Check Boxes disabled for check condition
Parameters
ChkBox : Name of the Check Box.
FrmName : Name of the form element.

*/

function disableCheckBox(ChkBox,FrmName)
{
	if(document.forms[FrmName].elements[ChkBox].checked=true)
	{
		document.forms[FrmName].elements[ChkBox].checked=true
	}
}


////////////////////////////////////////////////////////////////////////////////////////////

/*
By Sandip Hatkhamkar.
Date : 05-12-2000
Purpose : For adding items from source list box to destination list box.
Parameters
SrcList : Name of the source list box.
DestList : Name of the destination list box.

*/
 
//Add the selected items from the source to destination list

function addSrcToDestList(srcList,destList)
{
	destList = window.document.forms[0].elements[destList];
	srcList = window.document.forms[0].elements[srcList]; 
	var len = destList.length;
	
	for(var i = 0; i < srcList.length; i++)
	{
		if ((srcList.options[i] != null) && (srcList.options[i].selected))
		 {
			//Check if this value already exist in the destList or not
			//if not then add it otherwise do not add it.
				var found = false;
				for(var count = 0; count < len; count++)
				{
					if (destList.options[count] != null) 
					{
						if (srcList.options[i].text == destList.options[count].text)
						 {
							found = true;
							break;
		  				 }
					}
				}

				if (found != true)
				{
					destList.options[len] = new Option(srcList.options[i].text); 
					destList.options[len].selected=true
					len++;
				}
		}
    
    }
}

///////////////////////////////////////////////////////////////////////////////////////////

/*

By Sandip Hatkhamkar.
Date : 05-12-2000
Purpose : For removing items from destination list box.
Parameters
destList : Name of the destination list box.

*/

// Deletes from the destination list.

function deleteFromDestList(destList)
{
	var destList  = window.document.forms[0].elements[destList];
	var len = destList.options.length;	
	
		for(var i = (len-1); i >= 0; i--)
		{
			if ((destList.options[i] != null) && (destList.options[i].selected == true))
			{
				destList.options[i] = null;
			}
        }
}

///////////////////////////////////////////////////////////////////////////////////////////
/*

By Sandip Hatkhamkar.
Date : 07-12-2000
Purpose : For valdiating text box for comma separated input.
Parameters
frmName : Name of the form.
FldName: Name of the text box.

*/


function ValidateCommas(frmName,FldName)
{
var firstChar=""
var lastChar=""
var fld=""
var strprofileId=""
var invalidchar=""
var i

			fld=document.forms[frmName].elements[FldName].value
			i=0;
					
	
	if(fld=="") 
	{
		alert("Invalid input!\nPlease enter again.")				
		
	}			
	else
	{
				lastChar=document.forms[frmName].elements[FldName].value.substring(document.forms[frmName].elements[FldName].value.length-1)
				firstChar=document.forms[frmName].elements[FldName].value.substring(0,1)
		
			while(i<=document.forms[frmName].elements[FldName].value.length)
			{
						
				if(!(isNaN(fld.charAt(i)))||(fld.charAt(i)==","))
				{	
					//checking for commas in input string
					if((firstChar!="," )&&(lastChar!=","))
					{			
						if ((fld.substring(i,i-1)!=",") || (fld.substring(i,i+1)!=","))
						{
							null;
						}
						else
						{				
							strprofileId=strprofileId +document.forms[frmName].elements[FldName].value + ","													
							break;		
						}
				
				   }	
				   else
				   {	
										
						if(firstChar==",")
							{
								strprofileId=strprofileId + firstChar 														
							}
							else if(lastChar==",")	
							{						
								strprofileId=strprofileId + lastChar
							}
						
							    break;														
					
				   }
				
				
			//  }
				
		
			}
			else
			{
					invalidchar=invalidchar+document.forms[frmName].elements[FldName].value + ","
					break;										
			}				
							
				i++;
		}
		
  }
   	
   		if (strprofileId!="" && invalidchar!="")
		{							
				invalidchar=invalidchar.substring(0,invalidchar.length-1);
				alert("Incorrect entry at "+strprofileId+" in ProfileId \nPlease enter again!");
				invalidchar="";
				strprofileId="";
			
		}		
		else if(invalidchar!="") 
		{
			invalidchar=invalidchar.substring(0,invalidchar.length-1);
			alert("Invalid character in ProfileId at " +invalidchar+"\nPlease enter again!");
			invalidchar="";		
			
		}
		else if(strprofileId !="") 
		{
				alert("Incorrect entry at "+strprofileId+" in ProfileId \nPlease enter again!");
				strprofileId="";
			
		}
		else if (fld!="")
		{				
			document.forms[frmName].submit();
			
		}
			
 }
/////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

/*
By Sameer Sattur.
Date : 10-01-2001
Purpose : For adding items from source list box to destination list box along with the criteria of Ascending or Descending.
Parameters
SrcList : Name of the source list box.
DestList : Name of the destination list box.
Criteria : Ascending and Descending

*/
 
//Add the selected items from the source to destination list

function addSortSrcToDestList(srcList,destList,Criteria)
{
	
	destList = window.document.forms[0].elements[destList];
	srcList = window.document.forms[0].elements[srcList]; 
	
	var len = destList.length;
	
	for(var i = 0; i < srcList.length; i++)
	{
		if ((srcList.options[i] != null) && (srcList.options[i].selected))
		 {
			//Check if this value already exist in the destList or not
			//if not then add it otherwise do not add it.
				var found = false;
				for(var count = 0; count < len; count++)
				{
					if (destList.options[count] != null) 
					{
					var source = srcList.options[i].text
					var destination = destList.options[count].text
						if (destination.indexOf(source)!=-1)
						 {						
							destList.options[count] = new Option((srcList.options[i].text)+"-"+Criteria); 
						 	found = true;
							break;
		  				 }
					}
				}

				if (found != true)
				{
					destList.options[len] = new Option((srcList.options[i].text)+"-"+Criteria); 
					//destList.options[len].selected=true
					len++;
				}
		}
    
    }
}

///////////////////////////////////////////////////////////////////////////////////////////

/*

By Sameer Sattur.
Date : 10-01-2001
Purpose : For removing items from destination list box.
Parameters
destList : Name of the destination list box.

*/

// Deletes from the destination list.

function deleteFromDestList(destList)
{
	var destList  = window.document.forms[0].elements[destList];
	var len = destList.options.length;	
	
		for(var i = (len-1); i >= 0; i--)
		{
			if ((destList.options[i] != null) && (destList.options[i].selected == true))
			{
				destList.options[i] = null;
			}
        }
}


function checkSpace(FieldName)
{
	var str;
	var j=0;
	FldLength=FieldName.length;
	for(i=0;i<FieldName.length;i++)
	{
		if(FieldName.charAt(i)==" ")
		{
			j++;
		}
	}
	if(j==FldLength)
	{
		return true;
	}
	else
	{
		return false;
	}
}



function check_date(field)
/*
Purpose				:	This function is used to check if field passed to it
						contains a valid date in DD/MM/YYYY format.
						Changes have been made to check proper input by user.
Author 				:	Anil V.K.  (Copied from Net)
Last Updated		:	04 Mar 2002
*/
{
var checkstr = "0123456789";
var DateField = field;
var Datevalue = "";
var DateTemp = "";
var seperator = "/";
var NoofSeparators=0;
var properformat = checkstr + seperator;
var datewithpadding;
var NewDate = "";
var OldDate;
var day;
var month;
var year;
var leap = 0;
var err = 0;
var i;
var iCtr;

   err = 0;
    DateValue = DateField.value;
	OldDate = DateValue;

   /* check if the user has put in the value in proper format */
   for (i = 0; i < DateValue.length; i++) {
	  if (properformat.indexOf(DateValue.substr(i,1)) == -1) {
	     alert("Kindly enter the Date in DD/MM/YYYY format");
	      DateField.select();
		  DateField.focus();
	     return false;
	  }
	
	  if (DateValue.substr(i,1) == seperator)
	  {
		NoofSeparators = NoofSeparators + 1;
	  }
   }

	if (NoofSeparators != 2)
	{
		alert("Kindly enter the Date in DD/MM/YYYY format");
		DateField.select();
		DateField.focus();
		return false
	}
	

	datewithpadding = OldDate.split("/");

	for (i=0;i<	datewithpadding.length;i++)
	{
		//check for the Day on "99" format
		if (i == 0)
		{
			if (datewithpadding[i].length == 1)
			{
				NewDate = NewDate + "0" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				DateField.select();
				DateField.focus();
				return false;
			}
		}

		//check for the Month on "99" format
		if (i == 1)
		{
			if (datewithpadding[i].length == 1)
			{
				NewDate = NewDate + "0" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				DateField.select();
				DateField.focus();
				return false;
			}
		}

		//check for the Year on "9999" format
		if (i == 2)
		{
			if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "20" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 4)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				DateField.select();
				DateField.focus();
				return false;
			}
		}

	
	}
	
	//New Converted Value
	DateValue = NewDate;

   /* Delete all chars except 0..9 */
   for (i = 0; i < DateValue.length; i++) {
	  if (checkstr.indexOf(DateValue.substr(i,1)) >= 0) {
	     DateTemp = DateTemp + DateValue.substr(i,1);
	  }
   }
   DateValue = DateTemp;
   /* Always change date to 8 digits - string*/
   /* if year is entered as 2-digit / always assume 20xx */
   if (DateValue.length == 6) {
      DateValue = DateValue.substr(0,4) + '20' + DateValue.substr(4,2); }
   if (DateValue.length != 8) {
      err = 19;}
   /* year is wrong if year = 0000 */
   year = DateValue.substr(4,4);
   if (year == 0) {
      err = 20;
   }
   /* Validation of month*/
   month = DateValue.substr(2,2);
   if ((month < 1) || (month > 12)) {
      err = 21;
   }
   /* Validation of day*/
   day = DateValue.substr(0,2);
   if (day < 1) {
     err = 22;
   }
   /* Validation leap-year / february / day */
   if ((year % 4 == 0) || (year % 100 == 0) || (year % 400 == 0)) {
      leap = 1;
   }
   if ((month == 2) && (leap == 1) && (day > 29)) {
      err = 23;
   }
   if ((month == 2) && (leap != 1) && (day > 28)) {
      err = 24;
   }
   /* Validation of other months */
   if ((day > 31) && ((month == "01") || (month == "03") || (month == "05") || (month == "07") || (month == "08") || (month == "10") || (month == "12"))) {
      err = 25;
   }
   if ((day > 30) && ((month == "04") || (month == "06") || (month == "09") || (month == "11"))) {
      err = 26;
   }
   /* if 00 ist entered, no error, deleting the entry */
   if ((day == 0) && (month == 0) && (year == 00)) {
      err = 0; day = ""; month = ""; year = ""; seperator = "";
   }
   /* if no error, write the completed date to Input-Field (e.g. 13.12.2001) */
   if (err == 0) {
      DateField.value = day + seperator + month + seperator + year;
	  return true;
   }
   /* Error-message if err != 0 */
   else {
      alert("Date is incorrect!");
      DateField.select();
	  DateField.focus();
	  return false;
   }

//  End -->
}

function check_dateRangestring(parDateFld1, strDateFld1Name, parDateFld2, strDateFld2Name)
{
	var oDate1;
	var oDate2;
	
	if (parDateFld1 != "" && parDateFld2 != "" )
	{
		oDate1 = new Date(parDateFld1);
		oDate2 = new Date(parDateFld2);
	//	alert("Date 1" + oDate1);
	//	alert("Date 2" + oDate2);
		if (oDate1 > oDate2) 
		{
			alert(strDateFld1Name + " Cannot be greater than " + strDateFld2Name);
		//	parDateFld1.focus();
			return false;
		}
	}

}
function check_date_fortext(strDate)
/*
Purpose				:	This function is used to check if field value passed to it
						contains a valid date in DD/MM/YYYY format.
						Changes have been made to check proper input by user.
Author 				:	Anil V.K.  (Copied from Net)
Last Updated		:	04 Mar 2002
*/
{
var checkstr = "0123456789";
var Datevalue = "";
var DateTemp = "";
var seperator = "/";
var NoofSeparators=0;
var properformat = checkstr + seperator;
var datewithpadding;
var NewDate = "";
var OldDate;
var day;
var month;
var year;
var leap = 0;
var err = 0;
var i;
var iCtr;

   err = 0;
    DateValue = strDate;
	OldDate = DateValue;

   /* check if the user has put in the value in proper format */
   for (i = 0; i < DateValue.length; i++) {
	  if (properformat.indexOf(DateValue.substr(i,1)) == -1) {
	     alert("Kindly enter the Date in DD/MM/YYYY format");
	     return false;
	  }
	
	  if (DateValue.substr(i,1) == seperator)
	  {
		NoofSeparators = NoofSeparators + 1;
	  }
   }

	if (NoofSeparators != 2)
	{
		alert("Kindly enter the Date in DD/MM/YYYY format");
		return false
	}
	

	datewithpadding = OldDate.split("/");

	for (i=0;i<	datewithpadding.length;i++)
	{
		//check for the Day on "99" format
		if (i == 0)
		{
			if (datewithpadding[i].length == 1)
			{
				NewDate = NewDate + "0" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				return false;
			}
		}

		//check for the Month on "99" format
		if (i == 1)
		{
			if (datewithpadding[i].length == 1)
			{
				NewDate = NewDate + "0" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				return false;
			}
		}

		//check for the Year on "9999" format
		if (i == 2)
		{
			if (datewithpadding[i].length == 2)
			{
				NewDate = NewDate + "20" + datewithpadding[i];
			}
			else if (datewithpadding[i].length == 4)
			{
				NewDate = NewDate + "" + datewithpadding[i];
			}
			else
			{
				alert("Kindly enter the Date in DD/MM/YYYY format");
				return false;
			}
		}

	
	}
	
	//New Converted Value
	DateValue = NewDate;

   /* Delete all chars except 0..9 */
   for (i = 0; i < DateValue.length; i++) {
	  if (checkstr.indexOf(DateValue.substr(i,1)) >= 0) {
	     DateTemp = DateTemp + DateValue.substr(i,1);
	  }
   }
   DateValue = DateTemp;
   /* Always change date to 8 digits - string*/
   /* if year is entered as 2-digit / always assume 20xx */
   if (DateValue.length == 6) {
      DateValue = DateValue.substr(0,4) + '20' + DateValue.substr(4,2); }
   if (DateValue.length != 8) {
      err = 19;}
   /* year is wrong if year = 0000 */
   year = DateValue.substr(4,4);
   if (year == 0) {
      err = 20;
   }
   /* Validation of month*/
   month = DateValue.substr(2,2);
   if ((month < 1) || (month > 12)) {
      err = 21;
   }
   /* Validation of day*/
   day = DateValue.substr(0,2);
   if (day < 1) {
     err = 22;
   }
   /* Validation leap-year / february / day */
   if ((year % 4 == 0) || (year % 100 == 0) || (year % 400 == 0)) {
      leap = 1;
   }
   if ((month == 2) && (leap == 1) && (day > 29)) {
      err = 23;
   }
   if ((month == 2) && (leap != 1) && (day > 28)) {
      err = 24;
   }
   /* Validation of other months */
   if ((day > 31) && ((month == "01") || (month == "03") || (month == "05") || (month == "07") || (month == "08") || (month == "10") || (month == "12"))) {
      err = 25;
   }
   if ((day > 30) && ((month == "04") || (month == "06") || (month == "09") || (month == "11"))) {
      err = 26;
   }
   /* if 00 ist entered, no error, deleting the entry */
   if ((day == 0) && (month == 0) && (year == 00)) {
      err = 0; day = ""; month = ""; year = ""; seperator = "";
   }
   /* if no error, write the completed date to Input-Field (e.g. 13.12.2001) */
   if (err == 0) {
	  return true;
   }
   /* Error-message if err != 0 */
   else {
      alert("Date is incorrect!");
	  return false;
   }

//  End -->
}

function check_dateRange(parDateFld1, strDateFld1Name, parDateFld2, strDateFld2Name)
{
	var oDate1;
	var oDate2;
	
	if (parDateFld1.value != "" && parDateFld2.value != "" )
	{
		oDate1 = new Date(parDateFld1.value);
		oDate2 = new Date(parDateFld2.value);
		if (oDate1 > oDate2) 
		{
			alert(strDateFld1Name + " Cannot be greater than " + strDateFld2Name);
			parDateFld1.focus();
			return false;
		}
	}

}
function getdataforDisplay(strInputString,iMaxlength )
{
// Author - Jojo Koshy
// Date - 18/03/2002
// Purpose - For Constructing string for display.
	if (strInputString.length > iMaxlength)
	{
		strInputString = strInputString.substring(0,iMaxlength);
		strInputString = strInputString + "...";
	}
	return strInputString;
}

function isitToday(dateString,dateType) 
{
/*
	Copied from Internet by Anil V.K. 
	On 15 Mar 2002
	
   function isitToday 
   parameters: dateString dateType
   returns: boolean
   
   dateString is a date passed as a string in the following
   formats:

   type 1 : 19970529
   type 2 : 970529
   type 3 : 29/05/1997
   type 4 : 29/05/97
   
   dateType is a numeric integer from 1 to 4, representing
   the type of dateString passed, as defined above.

   Returns true if the date passed is equal to todays date
   Returns false if the date passed is NOT equal to todays
   date or if dateType is not 1 to 4.
	
	E.g

	if (isitToday("19970529",1)) alert('true'); else alert('false');

	if (isitToday("970529",2)) alert('true'); else alert('false');

	if (isitToday("29/05/1997",3)) alert('true'); else alert('false');

	if (isitToday("02/06/97",4)) alert('true'); else alert('false');


*/


    var now = new Date();
    var today = new Date(now.getYear(),now.getMonth(),now.getDate());

    if (dateType == 1)
        var date = new Date(dateString.substring(0,4),
                            dateString.substring(4,6)-1,
                            dateString.substring(6,8));
    else if (dateType == 2)
        var date = new Date(dateString.substring(0,2),
                            dateString.substring(2,4)-1,
                            dateString.substring(4,6));
    else if (dateType == 3)
        var date = new Date(dateString.substring(6,10),
                            dateString.substring(3,5)-1,
                            dateString.substring(0,2));
    else if (dateType == 4)
        var date = new Date(dateString.substring(6,8),
                            dateString.substring(3,5)-1,
                            dateString.substring(0,2));
    else
        return false;

    if (date.toString() == today.toString())
        return true;
    else
        return false;

}

function GetTodaysDate()
{
/*
Purpose			:	This function will return the current date
Author			:	Anil V.K.
Last Updated	:	15 Mar 2002

    var obj = new Object();
    var now = new Date();
    var today = new Date(now.getYear(),now.getMonth(),now.getDate());
	obj.value = today;
	return today;
	
	//return obj;
*/
   var now = new Date();
   var today;
   var todayMonth;
   var todayDate;
   todayDate = now.getDate();
   todayMonth = now.getMonth() + 1;  
   if (todayMonth < 10 )
   {
	todayMonth = "0" + todayMonth;
   }
   if (todayDate < 10 )
   {
	todayDate = "0" + todayDate;
   }
   today = todayMonth + "/" + todayDate  + "/" + now.getYear();
   return today;
}

///////////////////////////////////////////////////////////////////////////////////////////




//Function extOk for checking valid extension in email id.
//Created  by: Jayshri V. Gade.
//Date: 09/06/2007
function extOk(strId)
{
var arr = new Array('.COM','.EDU','.GOV','.NET','.BIZ','.ORG','.TV','.IN','.INFO','.NAME','.AF','.AL','.DZ','.As','.AD','.AO','.AI','.AQ','.AG','.AP','.AR','.AM','.AW','.AU','.AT','.AZ','.BS','.BH','.BD','.BB','.BY','.BE','.BZ','.BJ','.BM','.BT','.BO','.BA','.BW','.BV','.BR','.IO','.BN','.BG','.BF','.MM','.BI','.KH','.CM','.CA','.CV','.KY','.CF','.TD','.CL','.CN','.CX','.CC','.KM','.CG','.CD','.CK','.CR','.CI','.HR','.CU','.CY','.CZ','.DK','.DJ','.DM','.DO','.TP','.EC','.EG','.SV','.GQ','.ER','.EE','.ET','.FK','.FO','.FJ','.FI','.CS','.SU','.FR','.FX','.GF','.PF','.TF','.GA','.GM','.GE','.DE','.GH','.GI','.GB','.GR','.GL','.GD','.GP','.GU','.GT','.GN','.GW','.GY','.HT','.HM','.HN','.HK','.HU','.IS','.IN','.ID','.IR','.IQ','.IE','.IL','.IT','.JM','.JP','.JO','.KZ','.KE','.KI','.KW','.KG','.LA','.LV','.LB','.LS','.LR','.LY','.LI','.LT','.LU','.MO','.MK','.MG','.MW','.MY','.MV','.ML','.MT','.MH','.MQ','.MR','.MU','.YT','.MX','.FM','.MD','.MC','.MN','.MS','.MA','.MZ','.NA','.NR','.NP','.NL','.AN','.NT','.NC','.NZ','.NI','.NE','.NG','.NU','.NF','.KP','.MP','.NO','.OM','.PK','.PW','.PA','.PG','.PY','.PE','.PH','.PN','.PL','.PT','.PR','.QA','.RE','.RO','.RU','.RW','.GS','.SH','.KN','.LC','.PM','.ST','.VC','.SM','.SA','.SN','.SC','.SL','.SG','.SK','.SI','.SB','.SO','.ZA','.KR','.ES','.LK','.SD','.SR','.SJ','.SZ','.SE','.CH','.SY','.TJ','.TW','.TZ','.TH','.TG','.TK','.TO','.TT','.TN','.TR','.TM','.TC','.TV','.UG','.UA','.AE','.UK','.US','.UY','.UM','.UZ','.VU','.VA','.VE','.VN','.VG','.VI','.WF','.WS','.EH','.YE','.YU','.ZR','.ZM','.ZW');
var s=Trim(strId);
var dot = s.lastIndexOf(".");
//alert(dot);
var ext1 = s.substring(dot,s.length);

//alert(ext1);
var ext=ext1.toUpperCase();
//alert(ext);
var val = true;
if(dot>2 && dot<57)
{
	for(var i=0; i< arr.length;i++)
	{
	  if(ext==arr[i])
	  {
	 	val = true;
		break;
	  }	
	  else
	  {
	 	val = false;
	 	
	  }
	}
	
}
if(val==false)
{
alert("Your Domain name extension is not correct");
//strId.focus();
return false;
}	
}
//////////////////////////////////////////////////////////////////////////////

// function to check Valid Email Id	
//function EmailCheck() for checking all types of validation in Email Id:jayshri

function EmailCheck(strId)
{
	//Chech for @ and . in email address	
	//Modified By : Jayshri V. Gade.
		
		if(Trim(strId)!="")
		{
		//if(strId.value.lastIndexOf(" ")!=-1)
			//{
			//alert("Invalid Email Id")
			//strId.focus()
			//return false;
			//}
			var cnt=0;
			var cntdot=0;
			var s;
			s = Trim(strId);
			// is s whitespace?
			//alert("hi");
//jayshri added -07012008
			validstr=s.charAt(1);
			if (validstr=="@")
			{
				alert("This is not valid Email address, check it");
					//strId.focus();
					return false;
			}

			//code Updated By Pradeep on 23-02-08
//begin

			if (strId.indexOf("@.") >= 0)
			{
				alert("This is not valid Email address, check it");
				return false;
			}
			if (strId.indexOf("com.in") >= 0)
			{
				alert("This is not valid Email address, check it");
				return false;
			}
			if (strId.indexOf(" ") >= 0)
			{
				alert("This is not valid Email address, Remove any spaces");
				return false;
			}
//end			
			for (i = 0; i < s.length; i++)
			{   
			
				var c=s.charAt(i);
			    // Check that current character isn't whitespace.
			    if (c == " ")
			    {
					alert("This is not valid EMail address, check it");
					//strId.focus();
					return false;
			    }
			    if(c == ",")
			    {
			    alert("In Email id ,is not allowed");
			    //strId.focus();
			    return false;
			    }
				// Keep count of @
			    if (c == "@") cnt=cnt+1; 
			    // Keep count of .
			    if (c == ".") cntdot=cntdot+1;
			    
				if (i>0) 
				{
					if (c ==".")
					{
						var d=s.charAt(i-1);
						// if consecutive dots
							if (d == ".")
							{
								alert("This is not valid email address.");
								//strId.focus();
								return false;
							}
					 }			
				}
			}
			
		





	//var s=strId.value;
	
		var chr=s.charAt(0);
		var hh=s.charCodeAt(chr-1);
  var h=parseInt(hh);
if(((parseInt(hh)>32)&&(parseInt(hh)<46))||((parseInt(hh)>46)&&(parseInt(hh)<48))||((parseInt(hh)>57)&&(parseInt(hh)<64)))
{
alert("In Email id special character are not allowed");
//strId.focus();
return false;
}
	

			
			// if @ count greater than 1 or is 0
			// if dot count is 0
			if (cnt>1 || cnt==0 || cntdot==0)
			{
				alert("This is not valid email address.");
				//strId.focus();
				return false;
			}
			
    
			// there must be >= 1 character before @, so we
			// start looking at character position 1 
			// (i.e. second character)
			var i = 1;
			var sLength = s.length;
				if(sLength < 6)
				{
				alert("Email address is shorter than 6 characters which is impossible");
				//strId.focus();
				return false;
				}
				
			// look for @
			while ((i < sLength) && (s.charAt(i) != "@"))
			{ i++
			}

			if ((i >= sLength) || (s.charAt(i) != "@"))
			{
				alert("This is not valid email address.");
				//strId.focus();
				return false;
			}
			else i += 2;
			if((s.charAt(0)=="|")||(s.charAt(0)=="}")||(s.charAt(0)=="{")||(s.charAt(0)=="]")||(s.charAt(0)=="[")||(s.charAt(0)=="^")||(s.charAt(0)=="@")||(s.charAt(0)=="_")||(s.charAt(0)==".")||(s.charAt(0)=="'"))
			{
			alert("In Email id special character are not allowed");
				//strId.focus();
				return false;
			}

			while ((i < sLength) && (s.charAt(i) != "."))
			{ i++
			}

			// there must be at least one character after the .
			if ((i >= sLength - 1) || (s.charAt(i) != "."))
			{
				alert("This is not valid Email address.");
				//strId.focus();
				return false;			
			}			
		}
		else
		{
			alert("Please Enter a Valid Email Id");
			return false;
		}
	

		/*if(Trim(strId)!="")
		{
			//alert("Email test");
			//alert(document.forms[0].txtEmail.value);
			//if indexOf()  strList.indexOf("Current Job")
			
			if(strId.substring(strId.indexOf("@")+1, strId.length).toUpperCase() != "SAMPOORNA.COM")
			{
				if(Is_Login_EmailDuplicate(strId)==true)
				{
					//alert("Duplicate Email");
					return false;
				}
				else
				{
					//alert("Email OK");
					//return false;
					
				}
			}
			
		}*/
		
}
